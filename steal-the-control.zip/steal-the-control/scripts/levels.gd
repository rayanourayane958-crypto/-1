class_name Levels
## Single access point for all 15 level definitions.

const COUNT := 15
const W1 := preload("res://scripts/world1.gd")
const W2 := preload("res://scripts/world2.gd")
const W3 := preload("res://scripts/world3.gd")


static func all() -> Array:
	var out: Array = []
	out.append_array(W1.levels())
	out.append_array(W2.levels())
	out.append_array(W3.levels())
	return out


static func get_level(index: int) -> Dictionary:
	var list := all()
	if list.is_empty():
		return {}
	return list[clampi(index, 0, list.size() - 1)]


static func display_name(index: int) -> String:
	var d := get_level(index)
	return String(d.get("name", "Level %d" % (index + 1)))


static func world_of(index: int) -> int:
	var d := get_level(index)
	return int(d.get("world", 1))


static func world_name(w: int) -> String:
	match w:
		1:
			return "I. The Forgotten Buttons"
		2:
			return "II. The Broken Factory"
		_:
			return "III. The Control Core"


static func size_of(data: Dictionary) -> Vector2:
	var w := 56.0
	for s in data.get("solids", []):
		w = maxf(w, float(s[0]) + float(s[2]))
	for d in data.get("doors", []):
		w = maxf(w, float(d["x"]) + float(d["w"]))
	var ex: Array = data.get("exit", [50, 11])
	w = maxf(w, float(ex[0]) + 4.0)
	return Vector2(w * 16.0, 16.0 * 16.0)
