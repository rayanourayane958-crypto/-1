extends Node2D
class_name PlayerVisual
## Procedural cute white robot: squash and stretch, blinking eyes,
## swinging arms and legs, dash ghost trail, steal flash.

var facing := 1.0
var walk_phase := 0.0
var velocity := Vector2.ZERO
var grounded := true
var dashing := false
var gravity_sign := 1.0
var dead := false

var _squash := Vector2.ONE
var _blink := 0.0
var _blink_timer := 2.2
var _flash := 0.0
var _steal_flash := 0.0
var _steal_col := Color.WHITE
var _ghosts: Array = []
## Respawn materialise: 1.0 -> 0.0 over the respawn grace window.
var _spawn_in := 0.0
var _invuln := 0.0

const BODY := Color(0.97, 0.97, 1.0)
const SHADE := Color(0.70, 0.72, 0.92)
const OUTLINE := Color(0.07, 0.05, 0.16)
const EYE := Color(0.06, 0.05, 0.14)


func _process(delta: float) -> void:
	_anim(delta)
	queue_redraw()


func _anim(delta: float) -> void:
	var target := Vector2.ONE
	if dead:
		target = Vector2(1.5, 0.28)
	elif dashing:
		target = Vector2(1.3, 0.78)
	elif not grounded:
		target = Vector2(0.86, 1.16) if velocity.y * gravity_sign < 0.0 else Vector2(1.1, 0.92)
	else:
		var bob := sin(walk_phase * TAU) if absf(velocity.x) > 4.0 else 0.0
		target = Vector2(1.0 - bob * 0.07, 1.0 + bob * 0.07)
	_squash = _squash.lerp(target, clampf(delta * 16.0, 0.0, 1.0))

	_blink_timer -= delta
	if _blink_timer <= 0.0:
		_blink = 0.12
		_blink_timer = randf_range(1.6, 4.2)
	_blink = maxf(_blink - delta, 0.0)
	_flash = maxf(_flash - delta, 0.0)
	_steal_flash = maxf(_steal_flash - delta, 0.0)
	_spawn_in = maxf(_spawn_in - delta * 2.2, 0.0)
	_invuln = maxf(_invuln - delta, 0.0)

	_ghosts.clear()


func _draw() -> void:
	if dashing:
		for i in 3:
			var back := -facing * (8.0 + float(i) * 6.0)
			var a := 0.34 - float(i) * 0.09
			draw_rect(Rect2(back - 5.0, -5.0, 10.0, 11.0), Color(0.42, 0.79, 1.0, a))

	# Respawn materialise: an expanding ring plus rising motes, drawn under the body
	if _spawn_in > 0.0:
		var k := 1.0 - _spawn_in
		draw_arc(Vector2(0, -6), 4.0 + k * 20.0, 0, TAU, 22, Color(0.60, 0.95, 1.0, _spawn_in * 0.7), 1.5)
		for i in 6:
			var ang := TAU * float(i) / 6.0
			var p := Vector2(cos(ang) * 7.0, -6.0 + sin(ang) * 7.0 - k * 12.0)
			draw_rect(Rect2(p.x - 1, p.y - 1, 2, 2), Color(0.78, 1.0, 1.0, _spawn_in))
	# Soft shield ring instead of a hard flicker: readable grace, no strobing.
	if _invuln > 0.0 and _spawn_in <= 0.0:
		var pulse := 0.5 + 0.5 * sin(_invuln * 26.0)
		draw_arc(Vector2(0, -6), 11.0, 0, TAU, 20, Color(0.55, 0.90, 1.0, 0.14 + pulse * 0.18), 1.0)

	# soft contact shadow (unscaled, only when standing on something)
	if grounded and not dead:
		draw_set_transform(Vector2(0, 3), 0.0, Vector2(1.25, 0.42))
		draw_circle(Vector2.ZERO, 7.0, Color(0.02, 0.01, 0.06, 0.32))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	var spawn_scale := 1.0 - _spawn_in * 0.45
	var sx := _squash.x * facing * spawn_scale
	var sy := _squash.y * gravity_sign * spawn_scale
	draw_set_transform(Vector2(0, 2), 0.0, Vector2(sx, sy))

	# legs
	var leg_off := sin(walk_phase * TAU) * 2.0 if (grounded and absf(velocity.x) > 4.0) else 0.0
	draw_rect(Rect2(-5.0 + leg_off, -1.0, 3.0, 3.0), OUTLINE)
	draw_rect(Rect2(2.0 - leg_off, -1.0, 3.0, 3.0), OUTLINE)

	# arms
	var arm_off := -leg_off * 0.8
	draw_rect(Rect2(-8.5, -10.0 + arm_off, 3.0, 4.0), OUTLINE)
	draw_rect(Rect2(5.5, -10.0 - arm_off, 3.0, 4.0), OUTLINE)

	# antenna with a glowing tip
	draw_rect(Rect2(-0.5, -15.0, 1.0, 3.0), OUTLINE)
	draw_circle(Vector2(0.0, -15.6), 1.5, Color(1.0, 0.42, 0.68, 0.9))

	# body: rounded outline, top highlight, underside shade
	draw_rect(Rect2(-6.0, -12.0, 12.0, 13.0), OUTLINE)
	draw_rect(Rect2(-7.0, -11.0, 14.0, 11.0), OUTLINE)
	draw_rect(Rect2(-5.0, -11.0, 10.0, 11.0), BODY)
	draw_rect(Rect2(-6.0, -10.0, 12.0, 9.0), BODY)
	draw_rect(Rect2(-6.0, -3.0, 12.0, 2.0), SHADE)
	draw_rect(Rect2(-5.0, -1.0, 10.0, 1.0), SHADE.darkened(0.18))
	draw_rect(Rect2(-5.0, -11.0, 10.0, 1.0), Color(1, 1, 1, 0.9))

	# eyes
	var eye_h: float = 3.0 - _blink * 20.0
	eye_h = maxf(eye_h, 1.0)
	var look := facing * 0.9
	draw_rect(Rect2(-3.6 + look, -8.0, 2.4, eye_h), EYE)
	draw_rect(Rect2(1.2 + look, -8.0, 2.4, eye_h), EYE)
	if eye_h > 2.0:
		draw_rect(Rect2(-3.6 + look, -8.0, 1.0, 1.0), Color(1, 1, 1, 0.95))
		draw_rect(Rect2(1.2 + look, -8.0, 1.0, 1.0), Color(1, 1, 1, 0.95))

	# cheeks
	draw_rect(Rect2(-6.2, -5.0, 2.0, 1.0), Color(1.0, 0.55, 0.72, 0.7))
	draw_rect(Rect2(4.2, -5.0, 2.0, 1.0), Color(1.0, 0.55, 0.72, 0.7))

	# mouth: flat line normally, small "o" while falling fast
	if dead:
		draw_rect(Rect2(-1.5, -4.0, 3.0, 1.0), EYE)
	elif not grounded and velocity.y * gravity_sign > 180.0:
		draw_rect(Rect2(-1.0, -4.0, 2.0, 2.0), EYE)
	else:
		draw_rect(Rect2(-1.0 + look * 0.4, -4.0, 2.0, 1.0), EYE)

	if _steal_flash > 0.0:
		var a := _steal_flash / 0.35
		draw_rect(Rect2(-6.0, -11.0, 12.0, 11.0), Color(_steal_col.r, _steal_col.g, _steal_col.b, a * 0.8))
	if _flash > 0.0:
		draw_rect(Rect2(-6.0, -11.0, 12.0, 11.0), Color(1, 0.3, 0.35, _flash * 2.0))

	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func on_jump() -> void:
	_squash = Vector2(0.76, 1.26)


func on_land() -> void:
	_squash = Vector2(1.35, 0.7)
	_flash = 0.0


func on_dash() -> void:
	_squash = Vector2(1.45, 0.72)


func on_special() -> void:
	_squash = Vector2(0.7, 1.35)


func on_steal(c: Color) -> void:
	_steal_flash = 0.35
	_steal_col = c
	_squash = Vector2(1.3, 0.75)


func die() -> void:
	dead = true


func reset_visual() -> void:
	dead = false
	_squash = Vector2.ONE
	_ghosts.clear()
	_flash = 0.0


## Called on respawn so the robot visibly reassembles instead of popping in.
func on_respawn(grace: float) -> void:
	_spawn_in = 1.0
	_invuln = maxf(grace, 0.0)
	_squash = Vector2(0.4, 1.5)
