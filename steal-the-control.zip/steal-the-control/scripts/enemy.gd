extends CharacterBody2D
class_name Enemy
## All five enemy archetypes in one script, selected by `kind`.
## blue=jumper(jump) green=walker(left) yellow=dasher(dash)
## purple=gravity(gravity) red=thief(steals from the player)
## teal=chrono(time steal)

@export var kind := "blue"
@export var patrol_tiles := 3
@export var start_ability := true

const GRAVITY := 900.0
const SPEED := 42.0
const DASH_SPEED := 250.0

var ability := ""
var carry := false
var alive := true
var facing := -1.0
var home := Vector2.ZERO
var spawn_pos := Vector2.ZERO
var patrol_min := 0.0
var patrol_max := 0.0
var timer := 0.0
var state := "idle"
var gravity_sign := 1.0
var stolen_from_player := ""
var hit_flash := 0.0
var bob := 0.0
var _t := 0.0
var hurt_cooldown := 0.0
var look_x := 0.0
var stun_time := 0.0

signal player_stolen(ability: String)
signal defeated(enemy: Enemy)


func _ready() -> void:
	add_to_group("enemies")
	ability = _ability_for(kind)
	carry = start_ability and ability != ""
	home = global_position
	spawn_pos = global_position
	patrol_min = home.x - patrol_tiles * 16.0
	patrol_max = home.x + patrol_tiles * 16.0
	timer = randf_range(0.3, 1.2)
	if kind == "purple":
		gravity_sign = -1.0
	if kind == "teal":
		# a floating chrono wisp: no gravity, hovers above the floor
		gravity_sign = 0.0
	if kind == "red":
		carry = false
	z_index = 3


func _ability_for(k: String) -> String:
	match k:
		"blue":
			return "jump"
		"green":
			return "left"
		"yellow":
			return "dash"
		"purple":
			return "gravity"
		"teal":
			return "time"
	return ""


func target_ability() -> String:
	if kind == "red":
		return stolen_from_player
	return ability


func has_ability_available() -> bool:
	if not alive:
		return false
	if kind == "red":
		return stolen_from_player != ""
	return carry


func take_ability() -> String:
	if not has_ability_available():
		return ""
	if kind == "red":
		var ab := stolen_from_player
		stolen_from_player = ""
		hit_flash = 0.35
		stun_time = 2.0
		return ab
	carry = false
	hit_flash = 0.35
	stun_time = 2.0
	return ability


func _physics_process(delta: float) -> void:
	_t += delta
	bob = sin(_t * 3.0) * 1.5
	hit_flash = maxf(hit_flash - delta, 0.0)
	# TIME STEAL compresses only this enemy's own clock. Visual timers above
	# keep real time so a slowed enemy still looks alive, not frozen.
	var dt := delta * GameState.time_factor()
	hurt_cooldown = maxf(hurt_cooldown - dt, 0.0)
	stun_time = maxf(stun_time - dt, 0.0)
	if not alive:
		return
	# brief helpless window after its ability is stolen: room to breathe
	if stun_time > 0.0:
		_apply_gravity(dt)
		velocity.x = move_toward(velocity.x, 0.0, 300.0 * dt)
		move_and_slide()
		queue_redraw()
		return
	var p := get_tree().get_first_node_in_group("player") as Player
	if p != null:
		look_x = clampf(signf(p.global_position.x - global_position.x) * facing * 0.8, -0.8, 0.8)
	match kind:
		"blue":
			_blue(dt)
		"green":
			_green(dt, p)
		"yellow":
			_yellow(dt, p)
		"purple":
			_purple(dt)
		"red":
			_red(dt, p)
		"teal":
			_teal(dt, p)
	queue_redraw()


func _apply_gravity(delta: float) -> void:
	velocity.y += GRAVITY * gravity_sign * delta
	velocity.y = clampf(velocity.y, -420.0, 420.0)


func _blue(delta: float) -> void:
	timer -= delta
	_apply_gravity(delta)
	if timer <= 0.0:
		timer = 1.5
		velocity.y = -270.0 * gravity_sign
		velocity.x = facing * 62.0
		facing = -facing
		if carry:
			Sfx.play("alert", 1.3)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 200.0 * delta)
	move_and_slide()
	if is_on_wall():
		facing = -facing


func _green(delta: float, p: Player) -> void:
	_apply_gravity(delta)
	var spd := SPEED
	if p and absf(p.global_position.y - global_position.y) < 40.0:
		var dx: float = p.global_position.x - global_position.x
		if absf(dx) < 80.0:
			# signf() returns 0 when perfectly aligned, which froze the walker
			# while it kept that alignment. Keep the current facing instead.
			var s := signf(dx)
			if s != 0.0:
				facing = s
			spd = SPEED * 1.9
			if carry:
				pass
	velocity.x = facing * spd
	move_and_slide()
	if global_position.x < patrol_min:
		facing = 1.0
	elif global_position.x > patrol_max:
		facing = -1.0
	if is_on_wall():
		facing = -facing


## Chrono wisp: hovers on a drifting arc and leans toward the player when it
## gets close. No gravity, so it never falls off its patrol shelf.
func _teal(delta: float, p: Player) -> void:
	var target := Vector2(
		spawn_pos.x + sin(_t * 0.9) * patrol_tiles * 16.0,
		spawn_pos.y - 10.0 + cos(_t * 1.4) * 7.0
	)
	if p != null:
		var to_p := p.global_position - global_position
		if to_p.length() < 150.0:
			target = target.lerp(p.global_position + Vector2(0, -6), 0.5)
	var dir := target - global_position
	if dir.length() > 1.0:
		velocity = dir.normalized() * SPEED * 0.85
	else:
		velocity = Vector2.ZERO
	if absf(velocity.x) > 1.0:
		facing = signf(velocity.x)
	move_and_slide()


func _yellow(delta: float, p: Player) -> void:
	_apply_gravity(delta)
	timer -= delta
	match state:
		"idle":
			velocity.x = move_toward(velocity.x, 0.0, 400.0 * delta)
			if timer <= 0.0:
				state = "warn"
				timer = 0.55
				if p:
					facing = signf(p.global_position.x - global_position.x)
					if facing == 0.0:
						facing = -1.0
				if carry:
					Sfx.play("alert")
		"warn":
			velocity.x = 0.0
			if timer <= 0.0:
				state = "dash"
				timer = 0.34
				Sfx.play("dash", 1.2)
		"dash":
			velocity.x = facing * DASH_SPEED
			if timer <= 0.0:
				state = "idle"
				timer = 1.3
	move_and_slide()
	if is_on_wall() and state == "dash":
		state = "idle"
		timer = 1.0
		facing = -facing


func _purple(delta: float) -> void:
	_apply_gravity(delta)
	timer -= delta
	if timer <= 0.0:
		timer = 1.7
		gravity_sign *= -1.0
		velocity.y = 90.0 * gravity_sign
	velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
	move_and_slide()


func _red(delta: float, p: Player) -> void:
	_apply_gravity(delta)
	if p:
		var dx: float = p.global_position.x - global_position.x
		var dy: float = p.global_position.y - global_position.y
		if absf(dx) > 6.0:
			facing = signf(dx)
			velocity.x = facing * 58.0
		else:
			velocity.x = 0.0
		if stuck_ability() == "" and absf(dx) < 18.0 and absf(dy) < 16.0 and hurt_cooldown <= 0.0:
			_steal_from_player(p)
		elif stuck_ability() != "" and absf(dx) < 20.0 and absf(dy) < 18.0:
			_steal_from_player(p)
	else:
		velocity.x = 0.0
	move_and_slide()
	if global_position.x < patrol_min - 40.0:
		velocity.x = SPEED
	elif global_position.x > patrol_max + 40.0:
		velocity.x = -SPEED


func stuck_ability() -> String:
	return stolen_from_player


func _steal_from_player(p: Player) -> void:
	hurt_cooldown = 1.6
	if stolen_from_player == "":
		for a in ["dash", "gravity", "jump", "left"]:
			if GameState.has(a) and GameState.take(a):
				stolen_from_player = a
				Sfx.play("drain")
				player_stolen.emit(a)
				hit_flash = 0.35
				return
		# nothing to steal: nudge the player back
		if p is CharacterBody2D:
			p.velocity.x = signf(p.global_position.x - global_position.x) * 120.0
			p.velocity.y = -120.0


func damage() -> void:
	if not alive:
		return
	alive = false
	defeated.emit(self)
	if ability != "" and carry:
		carry = false
		pass
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(1.6, 0.3), 0.12)
	tw.parallel().tween_property(self, "modulate:a", 0.0, 0.25)
	tw.tween_callback(queue_free)


func _draw() -> void:
	if not alive:
		return
	var col := _body_color()
	var dark := col.darkened(0.55)
	var glow := col.lightened(0.35)
	var squash := Vector2.ONE
	if kind == "yellow" and state == "warn":
		var s := sin(_t * 55.0) * 0.12
		squash = Vector2(1.0 + s, 1.0 - s)
	elif kind == "blue" and velocity.y * gravity_sign < -20.0:
		squash = Vector2(0.88, 1.14)
		# contact shadow, drawn before the squash transform
	draw_set_transform(Vector2(0, 1), 0.0, Vector2(1.25, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0.02, 0.01, 0.06, 0.26))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	draw_set_transform(Vector2(0, bob), 0.0, Vector2(squash.x * facing, squash.y * gravity_sign))

	# feet / locomotion gear per archetype
	match kind:
		"blue":
			draw_rect(Rect2(-6, -1, 4, 3), dark)
			draw_rect(Rect2(2, -1, 4, 3), dark)
			draw_rect(Rect2(-6, 2, 4, 1), glow)
			draw_rect(Rect2(2, 2, 4, 1), glow)
		"green":
			draw_rect(Rect2(-7, -2, 14, 3), dark.darkened(0.25))
			draw_rect(Rect2(-6, -1, 3, 1), glow)
			draw_rect(Rect2(3, -1, 3, 1), glow)
		"yellow":
			draw_rect(Rect2(-5, -1, 3, 2), dark)
			draw_rect(Rect2(2, -1, 3, 2), dark)
			if state == "dash":
				draw_rect(Rect2(-10, -7, 4, 7), Color(1, 0.86, 0.3, 0.4))
				draw_rect(Rect2(-15, -6, 4, 5), Color(1, 0.86, 0.3, 0.22))
		"purple":
			draw_circle(Vector2(0, 1), 3.0 + sin(_t * 6.0) * 0.6, Color(glow.r, glow.g, glow.b, 0.45))
			draw_circle(Vector2(0, 1), 1.2, Color(1, 1, 1, 0.7))
		"red":
			draw_rect(Rect2(-6, -1, 12, 2), dark)
			draw_rect(Rect2(-8, -2, 2, 2), glow)
			draw_rect(Rect2(6, -2, 2, 2), glow)
		_:
			draw_rect(Rect2(-6, -2, 4, 3), dark)
			draw_rect(Rect2(2, -2, 4, 3), dark)

	# shell
	draw_rect(Rect2(-7, -13, 14, 12), dark)
	draw_rect(Rect2(-6, -12, 12, 9), col)
	draw_rect(Rect2(-6, -12, 12, 1), col.lightened(0.45))
	draw_rect(Rect2(-6, -4, 12, 2), col.darkened(0.4))

	# visor with two glowing eyes that track the player
	draw_rect(Rect2(-6, -10, 12, 5), Color(0.05, 0.04, 0.11))
	draw_rect(Rect2(-5, -9, 10, 3), Color(glow.r, glow.g, glow.b, 0.22))
	draw_rect(Rect2(-4.0 + look_x, -9, 2.4, 2.6), glow)
	draw_rect(Rect2(1.6 + look_x, -9, 2.4, 2.6), glow)
	draw_rect(Rect2(-3.4 + look_x, -8.4, 1.0, 1.2), Color(1, 1, 1, 0.95))
	draw_rect(Rect2(2.2 + look_x, -8.4, 1.0, 1.2), Color(1, 1, 1, 0.95))

	# antenna with a pulsing bulb
	draw_rect(Rect2(-0.6, -17, 1.2, 4), dark)
	draw_circle(Vector2(0, -17.5), 1.9 + sin(_t * 5.0) * 0.3, glow)

	if hit_flash > 0.0:
		draw_rect(Rect2(-7, -13, 14, 12), Color(1, 1, 1, hit_flash * 2.0))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	if kind == "red":
		_draw_red_extra()
	elif carry and ability != "":
		_draw_ability_tag()


func _body_color() -> Color:
	match kind:
		"blue":
			return Color("3d7bff") if carry else Color("3b4368")
		"green":
			return Color("4ade5e") if carry else Color("3b4368")
		"yellow":
			return Color("ffd233") if carry else Color("3b4368")
		"purple":
			return Color("a855f7") if carry else Color("3b4368")
		"red":
			return Color("ff4d5e")
		"teal":
			return Color("58f0c8") if carry else Color("3b4368")
	return Color("3b4368")


func _draw_ability_tag() -> void:
	var c: Color = GameState.color_of(ability)
	var y := -26.0 + sin(_t * 4.0) * 2.0
	draw_rect(Rect2(-9, y - 8, 18, 16), Color(0.05, 0.04, 0.11, 0.85))
	draw_rect(Rect2(-9, y - 8, 18, 16), c, false, 1.0)
	Icons.draw_ability(self, ability, Vector2(0, y), 4.0, c)


func _draw_red_extra() -> void:
	if stolen_from_player != "":
		var c: Color = GameState.color_of(stolen_from_player)
		var y := -26.0 + sin(_t * 6.0) * 2.0
		draw_rect(Rect2(-9, y - 8, 18, 16), Color(0.15, 0.02, 0.06, 0.9))
		draw_rect(Rect2(-9, y - 8, 18, 16), c, false, 1.0)
		Icons.draw_ability(self, stolen_from_player, Vector2(0, y), 4.0, c)
	var pulse := (sin(_t * 5.0) + 1.0) * 0.5
	draw_arc(Vector2.ZERO, 14.0 + pulse * 2.0, 0, TAU, 16, Color(1, 0.25, 0.35, 0.35 * pulse), 1.0)
