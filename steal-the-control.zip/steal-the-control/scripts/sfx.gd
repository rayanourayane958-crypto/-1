extends Node
## Tiny procedural sound engine: every effect is synthesized at startup,
## so the project ships with zero external audio files.

const RATE := 22050

var _players: Array[AudioStreamPlayer] = []
var _streams := {}
var enabled := true


func _ready() -> void:
	for i in 10:
		var p := AudioStreamPlayer.new()
		p.volume_db = -4.0
		add_child(p)
		_players.append(p)
	_build()


func _build() -> void:
	_streams["jump"] = _tone(320.0, 640.0, 0.12, "square", 0.22)
	_streams["land"] = _tone(220.0, 120.0, 0.09, "square", 0.18)
	_streams["steal"] = _tone(420.0, 980.0, 0.20, "saw", 0.20)
	_streams["drain"] = _tone(500.0, 180.0, 0.18, "square", 0.16)
	_streams["dash"] = _tone(700.0, 240.0, 0.14, "saw", 0.18)
	_streams["special"] = _tone(180.0, 620.0, 0.26, "sine", 0.22)
	_streams["hurt"] = _tone(300.0, 70.0, 0.24, "square", 0.24)
	_streams["coin"] = _tone(900.0, 1300.0, 0.10, "sine", 0.22)
	_streams["check"] = _tone(560.0, 840.0, 0.16, "sine", 0.22)
	# Checkpoint activation: a warmer, longer two-stage rise than "check".
	_streams["save"] = _tone(480.0, 1180.0, 0.30, "sine", 0.26)
	_streams["exit"] = _tone(520.0, 1040.0, 0.34, "sine", 0.24)
	_streams["ui"] = _tone(660.0, 660.0, 0.07, "square", 0.16)
	_streams["alert"] = _tone(760.0, 520.0, 0.10, "square", 0.16)
	# TIME STEAL: a downward sweep that reads as the world slowing around you.
	_streams["time"] = _tone(880.0, 150.0, 0.42, "sine", 0.24)


func _tone(f0: float, f1: float, dur: float, wave: String, vol: float) -> AudioStreamWAV:
	var count := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(count * 2)
	var phase := 0.0
	for i in count:
		var t := float(i) / float(count)
		var f: float = lerpf(f0, f1, t)
		phase += TAU * f / float(RATE)
		var s := 0.0
		match wave:
			"square":
				s = 1.0 if sin(phase) >= 0.0 else -1.0
			"saw":
				s = 2.0 * fmod(phase / TAU, 1.0) - 1.0
			"noise":
				s = randf() * 2.0 - 1.0
			_:
				s = sin(phase)
		var env: float = pow(1.0 - t, 1.7)
		var attack: float = minf(1.0, t * 40.0)
		var v := int(clampf(s * env * attack * vol, -1.0, 1.0) * 32767.0)
		data.encode_s16(i * 2, v)
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = RATE
	st.stereo = false
	st.data = data
	return st


func play(sound: String, pitch: float = 1.0) -> void:
	if not enabled:
		return
	if not _streams.has(sound):
		return
	for p in _players:
		if not p.playing:
			p.stream = _streams[sound]
			p.pitch_scale = pitch
			p.play()
			return
	if _players.size() > 0:
		_players[0].stream = _streams[sound]
		_players[0].pitch_scale = pitch
		_players[0].play()
