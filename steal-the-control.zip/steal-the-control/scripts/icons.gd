class_name Icons
## Shared procedural ability icon drawing (enemies + HUD).

static func draw_ability(c: CanvasItem, ability: String, center: Vector2, s: float, col: Color) -> void:
	match ability:
		"right":
			_arrow(c, center, Vector2(1, 0), s, col)
		"left":
			_arrow(c, center, Vector2(-1, 0), s, col)
		"jump":
			_arrow(c, center, Vector2(0, -1), s, col)
		"dash":
			_chevron(c, center - Vector2(s * 0.55, 0), s, col)
			_chevron(c, center + Vector2(s * 0.35, 0), s, col)
		"gravity":
			_ring(c, center, s, col)
		"time":
			# clock face: ring plus a hand pointing up-right
			_ring(c, center, s, col)
			c.draw_line(center, center + Vector2(0, -s * 0.72), col, 1.0)
			c.draw_line(center, center + Vector2(s * 0.52, 0), col, 1.0)
		_:
			c.draw_circle(center, s * 0.6, col)


static func _arrow(c: CanvasItem, center: Vector2, dir: Vector2, s: float, col: Color) -> void:
	var head_base := center
	var tip := center + dir * s
	var perp := Vector2(-dir.y, dir.x)
	var pts := PackedVector2Array([
		tip,
		head_base + perp * s * 0.9,
		head_base - perp * s * 0.9,
	])
	c.draw_colored_polygon(pts, col)
	var shaft_len: float = s * 1.25
	var thick: float = s * 0.62
	var a := center - dir * shaft_len
	var b := center
	var r: Rect2
	if absf(dir.x) > 0.5:
		r = Rect2(minf(a.x, b.x), center.y - thick * 0.5, absf(b.x - a.x), thick)
	else:
		r = Rect2(center.x - thick * 0.5, minf(a.y, b.y), thick, absf(b.y - a.y))
	c.draw_rect(r, col)


static func _chevron(c: CanvasItem, center: Vector2, s: float, col: Color) -> void:
	var pts := PackedVector2Array([
		center + Vector2(-s * 0.35, -s * 0.75),
		center + Vector2(s * 0.35, 0),
		center + Vector2(-s * 0.35, s * 0.75),
		center + Vector2(s * 0.05, 0),
	])
	c.draw_colored_polygon(pts, col)


static func _ring(c: CanvasItem, center: Vector2, s: float, col: Color) -> void:
	var outer := s * 0.95
	var pts := PackedVector2Array()
	var steps := 12
	for i in steps:
		var a := float(i) / float(steps) * TAU
		pts.append(center + Vector2(cos(a), sin(a)) * outer)
	c.draw_colored_polygon(pts, col)
	var inner := s * 0.42
	var pts2 := PackedVector2Array()
	for i in steps:
		var a := float(i) / float(steps) * TAU
		pts2.append(center + Vector2(cos(a), sin(a)) * inner)
	c.draw_colored_polygon(pts2, Color(0.06, 0.05, 0.12, 1.0))
