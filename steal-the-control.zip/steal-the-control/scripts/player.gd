extends CharacterBody2D
class_name Player
## Responsive platformer controller. Every movement option is gated behind
## an ability owned in GameState, except moving right.

signal died
signal stole(ability: String)

const MAX_SPEED := 122.0
const ACCEL := 1250.0
const AIR_ACCEL := 980.0
const DECEL := 1750.0
const GRAVITY := 980.0
const FALL_MAX := 430.0
const JUMP_V := 300.0
const COYOTE_TIME := 0.10
const JUMP_BUFFER := 0.12
const DASH_SPEED := 330.0
const DASH_TIME := 0.16
const DASH_COOLDOWN := 0.42
const STEAL_RANGE := 34.0
const SPECIAL_TIME := 1.1
const SPECIAL_COOLDOWN := 2.6
const TIME_COOLDOWN := 6.0

var gravity_sign := 1.0
var gravity_timer := 0.0
var special_cd := 0.0
var time_cd := 0.0
## Respawn grace: enemies cannot damage the player while this is above zero.
const INVULN_TIME := 1.5
var invuln := 0.0
var coyote := 0.0
var jump_buffer := 0.0
var dash_timer := 0.0
var dash_cd := 0.0
var dash_dir := 1.0
var facing := 1.0
var alive := true
var control_enabled := true
var walk_phase := 0.0
var spawn_position := Vector2.ZERO
## Diagnostic switch turned on by the headless jump test; silent in game.
var debug_jump := false

@onready var visual: PlayerVisual = $Visual
@onready var cam: Camera2D = $Camera2D


func _ready() -> void:
	add_to_group("player")
	spawn_position = global_position
	floor_snap_length = 4.0
	floor_stop_on_slope = true


func _physics_process(delta: float) -> void:
	# Godot's up_direction points AWAY from the surface you stand on, so under
	# normal gravity (gravity_sign = 1) up must be (0,-1). Writing gravity_sign
	# here inverted it: is_on_floor() was always false, coyote time never armed
	# and every jump was refused even when JUMP was owned.
	up_direction = Vector2(0, -gravity_sign)
	if not alive:
		velocity = Vector2.ZERO
		_update_visual(delta)
		return
	_tick_timers(delta)

	if not control_enabled:
		velocity.x = move_toward(velocity.x, 0.0, DECEL * delta)
		_apply_gravity(delta)
		move_and_slide()
		_update_visual(delta)
		return

	if dash_timer > 0.0:
		dash_timer -= delta
		velocity = Vector2(dash_dir * DASH_SPEED, 0.0)
		move_and_slide()
		if dash_timer <= 0.0:
			velocity.x *= 0.4
			dash_cd = DASH_COOLDOWN
		_update_visual(delta)
		return

	var dir := 0.0
	if Input.is_action_pressed("move_right"):
		dir += 1.0
	if GameState.has("left") and Input.is_action_pressed("move_left"):
		dir -= 1.0

	if dir != 0.0:
		facing = dir
		var a: float = ACCEL if _on_ground() else AIR_ACCEL
		velocity.x = move_toward(velocity.x, dir * MAX_SPEED, a * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, DECEL * delta)

	_apply_gravity(delta)

	if Input.is_action_just_pressed("jump"):
		request_jump()
	if Input.is_action_just_released("jump") and velocity.y * gravity_sign < 0.0:
		velocity.y *= 0.45
	if jump_buffer > 0.0 and coyote > 0.0 and GameState.has("jump") and alive:
		_do_jump()

	if Input.is_action_just_pressed("dash") and GameState.has("dash") and dash_cd <= 0.0:
		_start_dash()
	if Input.is_action_just_pressed("special") and GameState.has("gravity") and special_cd <= 0.0:
		_flip_gravity()
	if Input.is_action_just_pressed("time"):
		request_time_steal()

	var was_air := not _on_ground()
	move_and_slide()
	if _on_ground():
		coyote = COYOTE_TIME
		if was_air and absf(velocity.y) < 60.0:
			visual.on_land()
	_update_visual(delta)


func _tick_timers(delta: float) -> void:
	coyote = maxf(coyote - delta, 0.0)
	jump_buffer = maxf(jump_buffer - delta, 0.0)
	dash_cd = maxf(dash_cd - delta, 0.0)
	special_cd = maxf(special_cd - delta, 0.0)
	time_cd = maxf(time_cd - delta, 0.0)
	invuln = maxf(invuln - delta, 0.0)
	if gravity_timer > 0.0:
		gravity_timer -= delta
		if gravity_timer <= 0.0:
			gravity_sign = 1.0
			up_direction = Vector2(0, -1.0)
			velocity.y = 0.0


func _apply_gravity(delta: float) -> void:
	velocity.y += GRAVITY * gravity_sign * delta
	velocity.y = clampf(velocity.y, -FALL_MAX, FALL_MAX)


## "Up" follows the current gravity so floor detection stays correct when the
## SPECIAL ability flips the world.
func _on_ground() -> bool:
	return is_on_floor()


## Single entry point for a jump request: shared by input and by the headless
## regression test, so both exercise exactly the same path.
func request_jump() -> void:
	if not alive or not control_enabled:
		return
	jump_buffer = JUMP_BUFFER
	_log_jump("request")


## Silent unless debug_jump is enabled by the regression test.
func _log_jump(tag: String) -> void:
	if not debug_jump:
		return
	print("[jump] %s owned=%s on_floor=%s up=%s coyote=%.3f buffer=%.3f sign=%.1f vel=%s" % [
		tag, GameState.has("jump"), is_on_floor(), up_direction,
		coyote, jump_buffer, gravity_sign, velocity])


func _do_jump() -> void:
	_log_jump("fire")
	velocity.y = -JUMP_V * gravity_sign
	jump_buffer = 0.0
	coyote = 0.0
	Sfx.play("jump")
	visual.on_jump()


## TIME STEAL: slows enemies and hazards, never the player.
func request_time_steal() -> void:
	if not alive or not control_enabled:
		return
	if not GameState.has("time") or time_cd > 0.0:
		return
	if not GameState.start_slow():
		return
	time_cd = TIME_COOLDOWN
	Sfx.play("time")
	visual.on_special()


func _start_dash() -> void:
	dash_timer = DASH_TIME
	dash_dir = facing
	dash_cd = DASH_COOLDOWN + DASH_TIME
	Sfx.play("dash")
	visual.on_dash()


func _flip_gravity() -> void:
	gravity_sign *= -1.0
	up_direction = Vector2(0, -gravity_sign)
	gravity_timer = SPECIAL_TIME
	special_cd = SPECIAL_COOLDOWN
	# launch away from the surface we were standing on, toward the new "down"
	velocity.y = 80.0 * gravity_sign
	Sfx.play("special")
	visual.on_special()


func _update_visual(delta: float) -> void:
	if absf(velocity.x) > 4.0:
		walk_phase += absf(velocity.x) * delta * 0.16
	visual.facing = facing
	visual.walk_phase = walk_phase
	visual.velocity = velocity
	visual.grounded = _on_ground()
	visual.dashing = dash_timer > 0.0
	visual.gravity_sign = gravity_sign


func _unhandled_input(event: InputEvent) -> void:
	if not alive or not control_enabled:
		return
	if event.is_action_pressed("steal"):
		_try_steal()


func nearest_stealable() -> Enemy:
	var best: Enemy = null
	var best_d := STEAL_RANGE
	for node in get_tree().get_nodes_in_group("enemies"):
		var e := node as Enemy
		if e == null or not is_instance_valid(e):
			continue
		if not e.has_ability_available():
			continue
		var ab: String = e.target_ability()
		if ab != "" and GameState.has(ab):
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < best_d:
			best_d = d
			best = e
	return best


func _try_steal() -> void:
	var e := nearest_stealable()
	if e == null:
		return
	var ab: String = e.take_ability()
	if ab == "":
		return
	GameState.grant(ab)
	stole.emit(ab)
	Sfx.play("steal")
	visual.on_steal(GameState.color_of(ab))


func kill() -> void:
	if not alive:
		return
	alive = false
	control_enabled = false
	velocity = Vector2.ZERO
	Sfx.play("hurt")
	if visual.has_method("die"):
		visual.die()
	died.emit()


func respawn(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO
	gravity_sign = 1.0
	up_direction = Vector2(0, -1.0)
	gravity_timer = 0.0
	dash_timer = 0.0
	special_cd = 0.0
	time_cd = 0.0
	invuln = INVULN_TIME
	alive = true
	control_enabled = true
	if visual.has_method("reset_visual"):
		visual.reset_visual()
	if visual.has_method("on_respawn"):
		visual.on_respawn(invuln)
