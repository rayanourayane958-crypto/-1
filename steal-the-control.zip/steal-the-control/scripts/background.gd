extends Node2D
class_name GameBackground
## Cheap procedural parallax skyline. The three building layers are rasterized
## ONCE into textures (Image.fill_rect), so a frame costs ~100 draw calls
## instead of a thousand. No shaders, no external art.

const LAYER_W := 640
const LAYER_H := 180
const BASE_Y := 158

var camera: Camera2D = null
var world := 1

var _t := 0.0
var _stars: Array = []
var _far: Array = []
var _mid: Array = []
var _near: Array = []
var _tex := {}
var _layer_world := -1


func _ready() -> void:
	z_index = -20
	_build_geometry()
	_rebuild_layers()


func _build_geometry() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 90210
	for i in 64:
		_stars.append({
			"x": rng.randf_range(0, 320),
			"y": rng.randf_range(0, 142),
			"b": rng.randf_range(0.2, 1.0),
			"s": 1.5 if rng.randf() > 0.62 else 1.0,
			"p": rng.randf_range(0.0, TAU),
		})
	_far = _make(rng, 18, 26, 54, 34, 92)
	_mid = _make(rng, 16, 30, 66, 40, 108)
	_near = _make(rng, 12, 40, 82, 26, 66)


func _make(rng: RandomNumberGenerator, count: int, wmin: float, wmax: float, hmin: float, hmax: float) -> Array:
	var out: Array = []
	for i in count:
		out.append({
			"x": rng.randf_range(0, LAYER_W),
			"w": rng.randf_range(wmin, wmax),
			"h": rng.randf_range(hmin, hmax),
			"seed": rng.randf(),
		})
	return out


func _palette() -> Dictionary:
	match world:
		2:
			return {
				"top": Color("06121f"),
				"bot": Color("123748"),
				"far": Color("0a1d2b"),
				"mid": Color("0f2a3b"),
				"near": Color("08161f"),
				"glow": Color("39d4ff"),
				"win": Color("7ef2ff"),
			}
		3:
			return {
				"top": Color("10050c"),
				"bot": Color("3b0a20"),
				"far": Color("1c0713"),
				"mid": Color("2a0819"),
				"near": Color("12030c"),
				"glow": Color("ff4d6d"),
				"win": Color("ffb3c4"),
			}
	return {
		"top": Color("08061a"),
		"bot": Color("2b1550"),
		"far": Color("17102f"),
		"mid": Color("20143e"),
		"near": Color("100a22"),
		"glow": Color("b06bff"),
		"win": Color("ffd6ff"),
	}


## Rasterize one skyline layer into a wrapping texture.
func _raster(items: Array, base: Color, win: Color, windows: bool) -> ImageTexture:
	var img := Image.create(LAYER_W, LAYER_H, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for b in items:
		var w := float(b["w"])
		var h := float(b["h"])
		var x := float(b["x"])
		var top := float(BASE_Y) - h
		var rect := Rect2i(int(x), int(top), int(w), int(h))
		_fill_wrapped(img, rect, base)
		_fill_wrapped(img, Rect2i(rect.position.x, rect.position.y, rect.size.x, 2), base.lightened(0.22))
		# antenna / spire for a few towers
		var seedv := float(b["seed"])
		if seedv > 0.62:
			var ax := rect.position.x + rect.size.x / 2
			_fill_wrapped(img, Rect2i(ax, rect.position.y - 8, 2, 8), base.darkened(0.1))
			_fill_wrapped(img, Rect2i(ax - 1, rect.position.y - 10, 4, 2), base.lightened(0.3))
		if not windows:
			continue
		var row := 0
		var wy := rect.position.y + 7
		while wy < BASE_Y - 6:
			var col_i := 0
			var wx := rect.position.x + 5
			while wx < rect.position.x + rect.size.x - 5:
				var lit := fposmod(seedv * 97.0 + float(row * 13 + col_i * 29), 7.0) < 2.1
				if lit:
					var c := win.lerp(base, fposmod(float(row + col_i), 3.0) * 0.18)
					c.a = 0.72
					_fill_wrapped(img, Rect2i(wx, wy, 2, 3), c)
				wx += 8
				col_i += 1
			wy += 11
			row += 1
	return ImageTexture.create_from_image(img)


func _fill_wrapped(img: Image, r: Rect2i, col: Color) -> void:
	img.fill_rect(r, col)
	img.fill_rect(Rect2i(r.position.x + LAYER_W, r.position.y, r.size.x, r.size.y), col)
	img.fill_rect(Rect2i(r.position.x - LAYER_W, r.position.y, r.size.x, r.size.y), col)


func _rebuild_layers() -> void:
	var pal := _palette()
	_tex["far"] = _raster(_far, pal["far"], pal["win"], false)
	_tex["mid"] = _raster(_mid, pal["mid"], pal["win"], true)
	_tex["near"] = _raster(_near, pal["near"], pal["win"], true)
	_layer_world = world
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	if world != _layer_world:
		_rebuild_layers()
	queue_redraw()


func _draw() -> void:
	if _tex.is_empty():
		return
	var pal := _palette()
	var cam := get_viewport().get_camera_2d()
	var center := Vector2(160, 90)
	if cam != null:
		center = cam.get_screen_center_position()
	var origin := center - Vector2(160, 90)

	# sky gradient
	var bands := 16
	for i in bands:
		var f := float(i) / float(bands - 1)
		draw_rect(Rect2(origin.x, origin.y + f * 180.0, 320, 180.0 / float(bands) + 1.0), pal["top"].lerp(pal["bot"], f))

	# stars twinkle
	for s in _stars:
		var sx: float = fposmod(float(s["x"]) - center.x * 0.04, 320.0) + origin.x
		var sy: float = float(s["y"]) - center.y * 0.02 + origin.y * 0.0
		var twinkle: float = 0.55 + 0.45 * sin(_t * 1.6 + float(s["p"]))
		var b: float = float(s["b"]) * twinkle
		var sz: float = float(s["s"])
		draw_rect(Rect2(sx, sy + origin.y, sz, sz), Color(1, 1, 1, b * 0.9))

	# moon / core glow
	var glow: Color = pal["glow"]
	var moon := origin + Vector2(252.0 - center.x * 0.02, 40.0)
	draw_circle(moon, 26.0, Color(glow.r, glow.g, glow.b, 0.10))
	draw_circle(moon, 16.0, Color(glow.r, glow.g, glow.b, 0.16))
	draw_circle(moon, 10.0, Color(glow.r, glow.g, glow.b, 0.34))
	draw_circle(moon + Vector2(-3, -3), 4.0, Color(1, 1, 1, 0.35))

	_layer("far", center, 0.16, 0.05, origin, 0.0)
	_layer("mid", center, 0.32, 0.10, origin, 6.0)
	_layer("near", center, 0.58, 0.18, origin, 14.0)

	# faint haze at the bottom
	draw_rect(Rect2(origin.x, origin.y + 132, 320, 48), Color(pal["bot"].r, pal["bot"].g, pal["bot"].b, 0.45))


func _layer(key: String, center: Vector2, px: float, py: float, origin: Vector2, lift: float) -> void:
	var tex: ImageTexture = _tex.get(key, null)
	if tex == null:
		return
	var scroll: float = -center.x * px
	var start: float = origin.x + fposmod(scroll, float(LAYER_W)) - float(LAYER_W)
	var y: float = origin.y + float(BASE_Y) - float(LAYER_H) + lift - (-center.y * py) * 0.6
	draw_texture_rect(tex, Rect2(start, y, LAYER_W, LAYER_H), false)
	draw_texture_rect(tex, Rect2(start + LAYER_W, y, LAYER_W, LAYER_H), false)
	draw_texture_rect(tex, Rect2(start + LAYER_W * 2.0, y, LAYER_W, LAYER_H), false)
