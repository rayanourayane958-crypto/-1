extends Node2D
class_name VisualRect
## Small procedural pixel-art drawing helper used for blocks, doors,
## movers, conveyors, spikes, coins, checkpoints and the exit.

var kind := "block"
var size := Vector2(16, 16)
var fill := Color("2a2450")
var edge := Color("463a78")
var accent := Color("ff4fa3")
var direction := 1
var opened := 0.0
var active := false
var t := 0.0
var spin := 0.0
var star_phase := 0.0
## 1.0 right after a checkpoint is activated, decays to 0. Drives the burst.
var burst := 0.0


func _process(delta: float) -> void:
	t += delta
	burst = maxf(burst - delta, 0.0)
	if kind in ["door", "mover", "conveyor", "exit", "coin", "checkpoint"]:
		queue_redraw()


func _draw() -> void:
	match kind:
		"block":
			_draw_block()
		"door":
			_draw_door()
		"mover":
			_draw_mover()
		"conveyor":
			_draw_conveyor()
		"spike":
			_draw_spike()
		"coin":
			_draw_coin()
		"checkpoint":
			_draw_checkpoint()
		"exit":
			_draw_exit()


func _draw_block() -> void:
	# Blocks are drawn once (never animated), so this can afford real detail.
	var top_c := fill.lightened(0.15)
	var bot_c := fill.darkened(0.32)
	var bands := maxi(2, int(size.y / 10.0))
	var band_h := size.y / float(bands)
	for i in bands:
		var f := float(i) / float(maxi(bands - 1, 1))
		draw_rect(Rect2(0, float(i) * band_h, size.x, band_h + 1.0), top_c.lerp(bot_c, f))
	# bevel: light top edge, dark underside, lit left, shaded right
	draw_rect(Rect2(0, 0, size.x, 2), edge.lightened(0.45))
	draw_rect(Rect2(0, 2, size.x, 2), fill.lightened(0.22))
	draw_rect(Rect2(0, size.y - 3, size.x, 3), fill.darkened(0.55))
	draw_rect(Rect2(0, 0, 2, size.y), fill.lightened(0.08))
	draw_rect(Rect2(size.x - 2, 0, 2, size.y), fill.darkened(0.42))
	# panel grid
	var step := 16.0
	var gx := step
	while gx < size.x - 1.0:
		draw_rect(Rect2(gx, 4, 1, size.y - 7), fill.darkened(0.24))
		gx += step
	var gy := step
	while gy < size.y - 3.0:
		draw_rect(Rect2(2, gy, size.x - 4, 1), fill.darkened(0.28))
		gy += step
	# rivets top and bottom
	var rx := 9.0
	while rx < size.x - 5.0:
		draw_rect(Rect2(rx, 5, 2, 2), edge.lightened(0.55))
		draw_rect(Rect2(rx, size.y - 8, 2, 2), fill.darkened(0.65))
		rx += 24.0


func _draw_door() -> void:
	var alpha := 1.0 - opened
	var pulse := 0.5 + 0.5 * sin(t * 4.0)
	var ac := Color(accent.r, accent.g, accent.b, 1.0)
	# frame pillars stay visible, so an open gate still reads as a doorway
	draw_rect(Rect2(0, 0, 3, size.y), Color("1d1434"))
	draw_rect(Rect2(size.x - 3, 0, 3, size.y), Color("1d1434"))
	draw_rect(Rect2(0, 0, 3, size.y), Color(ac.r, ac.g, ac.b, 0.5), false, 1.0)
	draw_rect(Rect2(size.x - 3, 0, 3, size.y), Color(ac.r, ac.g, ac.b, 0.5), false, 1.0)
	draw_rect(Rect2(0, 0, size.x, 2), Color(ac.r, ac.g, ac.b, 0.55))
	if alpha <= 0.02:
		var ry := 7
		while ry < int(size.y) - 4:
			draw_rect(Rect2(3, float(ry), size.x - 6, 1), Color(ac.r, ac.g, ac.b, 0.09))
			ry += 10
		return
	# energy field
	draw_rect(Rect2(3, 2, size.x - 6, size.y - 4), Color(ac.r * 0.18, ac.g * 0.08, ac.b * 0.30, alpha * 0.95))
	var sy := 5.0 + fposmod(t * 16.0, 12.0)
	while sy < size.y - 6.0:
		draw_rect(Rect2(3, sy, size.x - 6, 1), Color(ac.r, ac.g, ac.b, alpha * (0.30 + pulse * 0.25)))
		sy += 12.0
	# hex cells
	var cy := 7.0
	var row := 0
	while cy < size.y - 7.0:
		var cx := 6.0 + (4.0 if row % 2 == 1 else 0.0)
		while cx < size.x - 6.0:
			draw_rect(Rect2(cx, cy, 3, 3), Color(ac.r, ac.g, ac.b, alpha * (0.16 + pulse * 0.14)))
			cx += 9.0
		cy += 9.0
		row += 1
	# lock while closed
	if alpha > 0.4:
		var lx := size.x * 0.5
		var ly := size.y * 0.5
		draw_rect(Rect2(lx - 3, ly - 3, 6, 6), Color(1, 1, 1, alpha * 0.85))
		draw_rect(Rect2(lx - 2, ly - 6, 4, 3), Color(1, 1, 1, alpha * 0.45), false, 1.0)


func _draw_mover() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("221a3d"))
	draw_rect(Rect2(0, 0, size.x, 4), Color("5a4e8c"))
	draw_rect(Rect2(0, size.y - 3, size.x, 3), Color("171232"))
	var c := accent
	var x := 3.0
	while x < size.x - 3.0:
		draw_rect(Rect2(x, 1, 3, 2), c)
		x += 10.0
	draw_rect(Rect2(0, 0, size.x, 1), Color(1, 1, 1, 0.25))


func _draw_conveyor() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("1d1738"))
	var off := fmod(t * 26.0 * float(direction), 12.0)
	var x: float = -12.0 + off
	while x < size.x + 12.0:
		var col := Color(0.35, 0.85, 1.0, 0.55)
		var pts := PackedVector2Array([
			Vector2(x, size.y * 0.5),
			Vector2(x + 6.0 * float(direction), size.y * 0.5 - 4),
			Vector2(x + 6.0 * float(direction), size.y * 0.5 + 4),
		])
		draw_colored_polygon(pts, col)
		x += 12.0
	draw_rect(Rect2(0, 0, size.x, 2), Color(0.4, 0.9, 1.0, 0.35))


func _draw_spike() -> void:
	var count := maxi(1, int(size.x / 8.0))
	var w := size.x / float(count)
	# steel base plate
	draw_rect(Rect2(0, size.y - 4, size.x, 4), Color("241b38"))
	draw_rect(Rect2(0, size.y - 4, size.x, 1), Color("4b3d6e"))
	draw_rect(Rect2(0, size.y - 1, size.x, 1), Color("100a1c"))
	for i in count:
		var bx := float(i) * w
		var tip := Vector2(bx + w * 0.5, 0)
		var pts := PackedVector2Array([Vector2(bx + 0.5, size.y - 3), tip, Vector2(bx + w - 0.5, size.y - 3)])
		draw_colored_polygon(pts, Color("e8edff"))
		# shaded half gives the blades depth
		var pts2 := PackedVector2Array([tip, Vector2(bx + w * 0.5, size.y - 3), Vector2(bx + w - 0.5, size.y - 3)])
		draw_colored_polygon(pts2, Color("9aa6e0"))
		draw_rect(Rect2(tip.x - 0.5, 2, 1, 3), Color(1, 1, 1, 0.9))


func _draw_coin() -> void:
	# a stolen "control chip" instead of a generic coin
	var spin := 0.55 + 0.45 * absf(cos(t * 2.6 + star_phase))
	var cy := -10.0 + sin(t * 2.4 + star_phase) * 1.5
	var w := 5.0 * spin
	draw_rect(Rect2(-w - 1, cy - 5, w * 2.0 + 2, 10), Color(0.05, 0.03, 0.1, 0.55))
	draw_rect(Rect2(-w, cy - 4, w * 2.0, 8), Color("ffc93c"))
	draw_rect(Rect2(-w, cy - 4, w * 2.0, 2), Color("ffe89a"))
	draw_rect(Rect2(-w * 0.55, cy - 1, w * 1.1, 3), Color("b57a12"))
	draw_rect(Rect2(-w * 0.5, cy - 2, w * 0.4, 2), Color("fff8d6"))
	# pins
	draw_rect(Rect2(-w - 1, cy - 1.5, 1, 1), Color("ffe89a"))
	draw_rect(Rect2(w, cy - 1.5, 1, 1), Color("ffe89a"))


func _draw_checkpoint() -> void:
	# Inactive reads as cold, switched-off hardware; active as a live green beacon.
	var col := Color("4ade5e") if active else Color("6b6f9a")
	var pulse := 0.5 + 0.5 * sin(t * (5.0 if active else 2.0))
	var lamp := Vector2(0, -30)

	# base pad
	draw_rect(Rect2(-7, -3, 14, 4), Color("1b1330"))
	draw_rect(Rect2(-7, -3, 14, 1), col.darkened(0.25))
	if active:
		draw_rect(Rect2(-5, -3, 10, 1), col.lightened(0.3))

	# pole with highlight
	draw_rect(Rect2(-1, -30, 2, 30), Color("8f97c9").darkened(0.35 if not active else 0.0))
	draw_rect(Rect2(-1, -30, 1, 30), Color("dfe3ff") if active else Color("9aa2c8"))

	# animated glowing core: stacked halos, brighter and larger when active
	if active:
		draw_circle(lamp, 9.0 + pulse * 2.5, Color(col.r, col.g, col.b, 0.07))
		draw_circle(lamp, 5.5 + pulse * 1.8, Color(col.r, col.g, col.b, 0.14))
		draw_circle(lamp, 3.2, Color(col.r, col.g, col.b, 0.45 + pulse * 0.25))
	else:
		draw_circle(lamp, 4.5, Color(col.r, col.g, col.b, 0.10))
	draw_circle(lamp, 1.8, col.lightened(0.25 if active else 0.0))
	draw_rect(Rect2(-0.5, -30.5, 1, 1), Color(1, 1, 1, 0.85 if active else 0.35))

	# flag: waves only once the point is live
	var wave := sin(t * 4.0) * 1.5 if active else 0.0
	var pts := PackedVector2Array([
		Vector2(1, -28),
		Vector2(13 + wave, -24),
		Vector2(1, -17),
	])
	draw_colored_polygon(pts, col)
	draw_colored_polygon(PackedVector2Array([Vector2(1, -28), Vector2(7 + wave * 0.5, -25.6), Vector2(1, -22)]), col.lightened(0.25))

	if active:
		draw_arc(Vector2(0, -14), 15.0 + sin(t * 3.0) * 2.0, 0, TAU, 20, Color(0.29, 0.87, 0.37, 0.22 + pulse * 0.10), 1.0)

	# activation burst: one expanding ring plus a cheap fan of sparks
	if burst > 0.0:
		var k := 1.0 - burst
		var r := 6.0 + k * 26.0
		draw_arc(Vector2(0, -16), r, 0, TAU, 24, Color(0.55, 1.0, 0.72, burst * 0.75), 1.5)
		for i in 8:
			var ang := TAU * float(i) / 8.0 + k * 1.4
			var d := Vector2(cos(ang), sin(ang) * 0.75)
			var p := Vector2(0, -16) + d * (5.0 + k * 22.0)
			draw_rect(Rect2(p.x - 1, p.y - 1, 2, 2), Color(0.62, 1.0, 0.78, burst))


func _draw_exit() -> void:
	var pulse := 0.5 + 0.5 * sin(t * 2.5)
	# soft halo so the goal reads from across the level
	draw_circle(Vector2(0, -17), 21.0 + pulse * 2.0, Color(1.0, 0.31, 0.64, 0.07))
	draw_circle(Vector2(0, -17), 13.0 + pulse * 1.5, Color(1.0, 0.45, 0.78, 0.10))
	# arch
	draw_rect(Rect2(-10, -32, 20, 32), Color("0f0820"))
	draw_rect(Rect2(-2, -36, 4, 4), Color("ff7bb8"))
	# pillars
	draw_rect(Rect2(-10, -32, 3, 32), Color("2a1745"))
	draw_rect(Rect2(7, -32, 3, 32), Color("2a1745"))
	draw_rect(Rect2(-10, -32, 3, 32), Color(1.0, 0.45, 0.78, 0.75), false, 1.0)
	draw_rect(Rect2(7, -32, 3, 32), Color(1.0, 0.45, 0.78, 0.75), false, 1.0)
	# portal interior
	draw_rect(Rect2(-7, -30, 14, 28), Color(0.32 + pulse * 0.12, 0.06, 0.42, 1.0))
	var sy := -29.0 + fposmod(t * 22.0, 7.0)
	while sy < -3.0:
		draw_rect(Rect2(-7, sy, 14, 1), Color(1, 0.68, 0.94, 0.22))
		sy += 7.0
	# upward chevrons
	for i in 3:
		var ay := -8.0 - float(i) * 7.0 + fposmod(t * 10.0, 7.0)
		if ay > -30.0 and ay < -4.0:
			draw_polyline(PackedVector2Array([Vector2(-4, ay), Vector2(0, ay - 3), Vector2(4, ay)]), Color(1, 1, 1, 0.35 + pulse * 0.3), 1.0)
	# base
	draw_rect(Rect2(-12, -2, 24, 2), Color(1.0, 0.55, 0.8, 0.9))
