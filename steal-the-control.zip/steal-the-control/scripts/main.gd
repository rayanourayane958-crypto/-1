extends Node2D
## Game controller: level flow, checkpoints, death/respawn, pause, menus.

@onready var world: Node2D = $World
@onready var level: LevelBuilder = $World/Level
@onready var player: Player = $World/Player
@onready var hud: GameHUD = $UILayer/HUD
@onready var menu: GameMenu = $UILayer/Menu
@onready var bg: GameBackground = $Background
@onready var cam: Camera2D = $World/Player/Camera2D
@onready var fade_rect: ColorRect = $UILayer/Fade

var current_index := 0
var playing := false
var respawning := false
var session_abilities: Array = ["right"]
var total_time := 0.0
var shake_time := 0.0
var shake_strength := 0.0
var _base_cam_offset := Vector2.ZERO


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	player.died.connect(_on_player_died)
	player.stole.connect(_on_player_stole)
	level.exit_reached.connect(_on_exit_reached)
	level.coins_changed.connect(_on_coins_changed)
	level.checkpoint_set.connect(_on_checkpoint)
	level.boss_defeated.connect(_on_boss_defeated)
	level.ability_drained.connect(_on_ability_drained)
	menu.play_requested.connect(_on_play)
	menu.resume_requested.connect(_resume)
	menu.restart_requested.connect(_on_restart)
	menu.quit_to_menu.connect(_on_quit_to_menu)
	menu.settings_changed.connect(_apply_settings)
	world.visible = false
	hud.visible = false
	player.set_physics_process(false)
	menu.show_screen("main")
	GameState.current_level = clampi(GameState.unlocked_levels - 1, 0, Levels.COUNT - 1)
	fade_rect.modulate.a = 1.0
	var intro := create_tween()
	intro.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	intro.tween_property(fade_rect, "modulate:a", 0.0, 0.5)


func _process(delta: float) -> void:
	hud.visible = playing and menu.screen == ""
	world.visible = playing and menu.screen in ["", "paused", "complete"]
	if shake_time > 0.0:
		shake_time -= delta
		var s := shake_strength * clampf(shake_time / 0.25, 0.0, 1.0)
		cam.offset = _base_cam_offset + Vector2(randf_range(-s, s), randf_range(-s, s))
	else:
		cam.offset = cam.offset.lerp(_base_cam_offset, clampf(delta * 10.0, 0.0, 1.0))
	if not playing:
		return
	if level.running:
		total_time += delta


func _apply_settings() -> void:
	GameState.apply_display()


func _on_play(index: int) -> void:
	_load_level(index)


## Fade out, rebuild, fade in: hides the pop of swapping level geometry.
func _load_level(index: int) -> void:
	await _transition(index, 0.15, 0.20)


func _transition(index: int, out_time: float, in_time: float) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "modulate:a", 1.0, out_time)
	await tw.finished
	start_level(index)
	var tw2 := create_tween()
	tw2.tween_property(fade_rect, "modulate:a", 0.0, in_time)


func start_level(index: int) -> void:
	current_index = clampi(index, 0, Levels.COUNT - 1)
	var data := Levels.get_level(current_index)
	if data.is_empty():
		return
	get_tree().paused = false
	playing = true
	respawning = false
	GameState.current_level = current_index
	var start_list: Array = data.get("start", ["right"]).duplicate()
	session_abilities = start_list.duplicate()
	GameState.reset_abilities(start_list)
	world.visible = true
	level.build(data, player)
	player.visible = true
	player.set_physics_process(true)
	player.respawn(level.spawn_pos)
	player.control_enabled = true

	cam.limit_left = 0
	cam.limit_top = -16
	cam.limit_right = int(level.bounds.x)
	cam.limit_bottom = int(level.bounds.y)
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 7.0
	cam.reset_smoothing()

	bg.world = int(data.get("world", 1))
	hud.attach(player, level, Levels.display_name(current_index))
	hud.show_hint(String(data.get("hint", "")))
	level.coins_changed.emit(0, level.coins_total)
	hud.set_progress(0, level.coins_total)
	hud.set_boss(level.boss)
	menu.show_screen("")
	level.running = true


func _on_player_stole(ability: String) -> void:
	if not session_abilities.has(ability):
		session_abilities.append(ability)
	var nm := String(GameState.ability_name.get(ability, ability))
	hud.show_toast(nm + " ACQUIRED", GameState.color_of(ability))
	_shake(1.2)


func _on_ability_drained(ability: String) -> void:
	var nm := String(GameState.ability_name.get(ability, ability))
	hud.show_toast(nm + " STOLEN!", Color("ff4d5e"))
	hud.flash_damage()
	_shake(2.0)


func _on_coins_changed(taken: int, total: int) -> void:
	hud.set_progress(taken, total)


func _on_checkpoint(pos: Vector2) -> void:
	hud.show_toast("CHECKPOINT", Color("4ade5e"))


func _on_player_died() -> void:
	if respawning or not playing:
		return
	respawning = true
	hud.flash_damage()
	_shake(1.6)
	await get_tree().create_timer(0.55).timeout
	if not playing:
		return
	GameState.reset_abilities(session_abilities)
	level.restore_enemies()
	level.guard_spawn(level.checkpoint_pos)
	player.respawn(level.checkpoint_pos)
	player.control_enabled = true
	cam.reset_smoothing()
	respawning = false


func _on_boss_defeated() -> void:
	hud.show_toast("CORES DESTROYED", Color("ff4fa3"))
	_shake(3.0)


func _on_exit_reached() -> void:
	if not playing:
		return
	playing = false
	player.control_enabled = false
	GameState.register_completion(current_index, level.time)
	if current_index >= Levels.COUNT - 1:
		GameState.unlocked_levels = Levels.COUNT
		GameState.save_game()
		menu.set_victory(total_time)
	else:
		var nxt := mini(current_index + 1, Levels.COUNT - 1)
		GameState.unlocked_levels = maxi(GameState.unlocked_levels, nxt + 1)
		GameState.save_game()
		menu.set_complete(current_index, level.time, level.coins_taken, level.coins_total)


func _on_restart() -> void:
	get_tree().paused = false
	await _transition(current_index, 0.12, 0.18)


func _on_quit_to_menu() -> void:
	get_tree().paused = false
	playing = false
	player.control_enabled = false
	world.visible = false
	hud.visible = false
	menu.show_screen("main")


func _unhandled_input(event: InputEvent) -> void:
	var key_event := event as InputEventKey
	if key_event != null and key_event.pressed and not key_event.echo and key_event.alt_pressed:
		if key_event.keycode == KEY_ENTER or key_event.keycode == KEY_KP_ENTER:
			GameState.toggle_fullscreen()
			_apply_settings()
			get_viewport().set_input_as_handled()
			return
	if event.is_action_pressed("ui_cancel"):
		_handle_cancel()
		get_viewport().set_input_as_handled()


func _handle_cancel() -> void:
	if menu.screen == "paused":
		_resume()
	elif playing and menu.screen == "":
		_pause()
	elif menu.screen in ["levels", "controls", "credits"] and menu.return_screen == "paused":
		menu.show_screen("paused")
	elif menu.screen in ["controls", "credits"]:
		menu.show_screen(menu.return_screen)
	elif menu.screen == "confirm_new":
		menu.show_screen("main")
	elif menu.screen != "" and menu.screen != "main":
		_on_quit_to_menu()


func _pause() -> void:
	get_tree().paused = true
	player.control_enabled = false
	menu.show_screen("paused")


func _resume() -> void:
	get_tree().paused = false
	menu.show_screen("")
	if playing:
		player.control_enabled = true


func _shake(strength: float) -> void:
	if not bool(GameState.settings.get("screenshake", false)):
		return
	shake_strength = strength
	shake_time = 0.22
