extends Control
class_name GameMenu
## All non-gameplay screens: main menu, level select, settings, pause,
## level complete, and the final victory screen.

signal play_requested(index: int)
signal resume_requested
signal restart_requested
signal quit_to_menu
signal settings_changed

var screen := "main"
var t := 0.0
var _font: Font = null
var _last_index := 0
var _complete_time := 0.0
var _complete_coins := 0
var _complete_total := 0
var _victory_time := 0.0
var _buttons: Array[Button] = []
var return_screen := "main"

const C_BG := Color("0b0820")
const C_PINK := Color("ff4fa3")
const C_CYAN := Color("35c9ff")
const C_GREEN := Color("4ade5e")
const C_YELLOW := Color("ffd233")
const C_PURPLE := Color("a855f7")


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_font = ThemeDB.fallback_font
	show_screen("main")


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func show_screen(name: String) -> void:
	screen = name
	visible = name != ""
	if name == "":
		_clear()
		return
	_build()


func _clear() -> void:
	for b in _buttons:
		if is_instance_valid(b):
			b.queue_free()
	_buttons.clear()
	for c in get_children():
		if c is Control and not (c is Button):
			c.queue_free()


func _mk_button(text: String, rect: Rect2, cb: Callable, accent: Color = C_PINK) -> Button:
	var b := Button.new()
	b.text = text
	b.position = rect.position
	b.size = rect.size
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_font_size_override("font_size", 9)
	b.add_theme_color_override("font_color", Color(0.95, 0.95, 1.0))
	b.add_theme_color_override("font_focus_color", Color(1, 1, 1))
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.add_theme_color_override("font_disabled_color", Color(0.4, 0.4, 0.5))
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.07, 0.05, 0.15, 0.92)
	normal.border_color = Color(accent.r, accent.g, accent.b, 0.55)
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(0)
	var hover := StyleBoxFlat.new()
	hover.bg_color = Color(accent.r * 0.45, accent.g * 0.35, accent.b * 0.55, 0.95)
	hover.border_color = accent
	hover.set_border_width_all(1)
	var focus := hover.duplicate()
	focus.bg_color = Color(accent.r * 0.32, accent.g * 0.24, accent.b * 0.42, 0.95)
	var pressed := hover.duplicate()
	pressed.bg_color = Color(accent.r * 0.6, accent.g * 0.5, accent.b * 0.7, 1.0)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("focus", focus)
	b.add_theme_stylebox_override("pressed", pressed)
	b.pressed.connect(cb)
	add_child(b)
	_buttons.append(b)
	return b


func _build() -> void:
	_clear()
	match screen:
		"main":
			_build_main()
		"levels":
			_build_levels()
		"settings":
			_build_settings()
		"paused":
			_build_paused()
		"complete":
			_build_complete()
		"victory":
			_build_victory()
		"confirm_new":
			_build_confirm_new()
		"controls":
			_build_controls()
		"credits":
			_build_credits()
	_focus_first()


func _focus_first() -> void:
	for b in _buttons:
		if is_instance_valid(b) and not b.disabled:
			b.grab_focus()
			return


func _build_main() -> void:
	var lx := 20.0
	var rx := 164.0
	var w := 136.0
	var h := 14.0
	# left column: the run itself
	var cont := _mk_button("CONTINUE", Rect2(lx, 96, w, h), func(): _continue_game(), C_PINK)
	cont.disabled = not GameState.has_progress()
	if cont.disabled:
		cont.text = "CONTINUE"
	_mk_button("NEW GAME", Rect2(lx, 114, w, h), func(): show_screen("confirm_new"), C_YELLOW)
	_mk_button("LEVEL SELECT", Rect2(lx, 132, w, h), func(): _open_levels("main"), C_CYAN)
	_mk_button("QUIT", Rect2(lx, 150, w, h), func(): get_tree().quit(), C_PURPLE)
	# right column: information
	_mk_button("SETTINGS", Rect2(rx, 96, w, h), func(): show_screen("settings"), C_GREEN)
	_mk_button("CONTROLS", Rect2(rx, 114, w, h), func(): _open_from("controls", "main"), C_YELLOW)
	_mk_button("CREDITS", Rect2(rx, 132, w, h), func(): _open_from("credits", "main"), C_CYAN)


func _continue_game() -> void:
	var idx: int = clampi(GameState.current_level, 0, GameState.unlocked_levels - 1)
	play_requested.emit(idx)


## Opens an info screen remembering where "back"/ESC should return to.
func _open_from(target: String, from_screen: String) -> void:
	return_screen = from_screen
	show_screen(target)


func _build_confirm_new() -> void:
	_mk_button("YES, START OVER", Rect2(80, 104, 160, 16), func(): _start_new_game(), C_PINK)
	_mk_button("CANCEL", Rect2(110, 126, 100, 14), func(): show_screen("main"), C_CYAN)


func _start_new_game() -> void:
	GameState.reset_progress()
	GameState.reset_abilities(["right"])
	settings_changed.emit()
	play_requested.emit(0)


func _build_controls() -> void:
	_mk_button("BACK", Rect2(110, 156, 100, 14), func(): show_screen(return_screen), C_CYAN)


func _build_credits() -> void:
	_mk_button("BACK", Rect2(110, 156, 100, 14), func(): show_screen(return_screen), C_CYAN)


func _build_levels() -> void:
	for row in 3:
		for col in 5:
			var i := row * 5 + col
			var unlocked: bool = i < GameState.unlocked_levels
			var done: bool = bool(GameState.completed.get(str(i), false))
			var colr := C_PINK if not done else C_GREEN
			if not unlocked:
				colr = Color("3a3550")
			var label := str(i + 1)
			if done:
				label = "OK"
			var b := _mk_button(label, Rect2(62 + col * 49, 42 + row * 27, 44, 21), func(): play_i(i), colr)
			b.disabled = not unlocked
	_mk_button("BACK", Rect2(110, 132, 100, 16), func(): show_screen(return_screen), C_CYAN)


func _open_levels(from_screen: String) -> void:
	return_screen = from_screen
	show_screen("levels")


func play_i(i: int) -> void:
	if i < GameState.unlocked_levels:
		play_requested.emit(i)


func _build_settings() -> void:
	var full: bool = GameState.setting("fullscreen")
	var sharp: bool = GameState.setting("pixel_perfect")
	var shake: bool = GameState.setting("screenshake")
	_mk_button("FULLSCREEN: " + ("ON" if full else "OFF"), Rect2(80, 74, 160, 18), func(): _toggle("fullscreen"), C_CYAN)
	_mk_button("PIXELS: " + ("SHARP" if sharp else "SMOOTH"), Rect2(80, 98, 160, 18), func(): _toggle("pixel_perfect"), C_PURPLE)
	_mk_button("SCREEN SHAKE: " + ("ON" if shake else "OFF"), Rect2(80, 122, 160, 18), func(): _toggle("screenshake"), C_YELLOW)
	_mk_button("BACK", Rect2(110, 150, 100, 16), func(): show_screen("main"), C_GREEN)


func _toggle(name: String) -> void:
	if name == "fullscreen":
		GameState.toggle_fullscreen()
	elif name == "pixel_perfect":
		GameState.toggle_pixel_perfect()
	else:
		GameState.set_setting(name, not GameState.setting(name))
		GameState.save_game()
	settings_changed.emit()
	screen = "settings"
	_build()
	_focus_first()


func _build_paused() -> void:
	_mk_button("RESUME", Rect2(110, 74, 100, 16), func(): resume_requested.emit(), C_GREEN)
	_mk_button("RESTART", Rect2(110, 93, 100, 16), func(): restart_requested.emit(), C_YELLOW)
	_mk_button("LEVEL SELECT", Rect2(110, 112, 100, 16), func(): _open_levels("paused"), C_CYAN)
	_mk_button("CONTROLS", Rect2(110, 131, 100, 16), func(): _open_from("controls", "paused"), C_YELLOW)
	_mk_button("MAIN MENU", Rect2(110, 150, 100, 16), func(): quit_to_menu.emit(), C_PINK)


func _build_complete() -> void:
	_mk_button("NEXT LEVEL", Rect2(110, 124, 100, 16), func(): _next_level(), C_GREEN)
	_mk_button("LEVEL SELECT", Rect2(110, 144, 100, 16), func(): _open_levels("main"), C_CYAN)


func _build_victory() -> void:
	_mk_button("PLAY AGAIN", Rect2(110, 138, 100, 16), func(): play_requested.emit(0), C_PINK)
	_mk_button("MAIN MENU", Rect2(110, 158, 100, 16), func(): show_screen("main"), C_CYAN)


func _next_level() -> void:
	var nxt: int = mini(_last_index + 1, Levels.COUNT - 1)
	if _last_index >= Levels.COUNT - 1:
		show_screen("victory")
	else:
		play_requested.emit(nxt)


func set_complete(index: int, time_seconds: float, coins: int, total: int) -> void:
	_last_index = index
	_complete_time = time_seconds
	_complete_coins = coins
	_complete_total = total
	show_screen("complete")


func set_victory(total_time: float) -> void:
	_victory_time = total_time
	show_screen("victory")


func _draw() -> void:
	if not visible:
		return
	# backdrop
	draw_rect(Rect2(0, 0, 320, 180), Color(C_BG.r, C_BG.g, C_BG.b, 0.88))
	for i in 34:
		var x := fposmod(float(i * 97) + t * (6.0 + float(i % 5)), 330.0) - 5.0
		var y := fposmod(float(i * 53), 180.0)
		var a := 0.15 + 0.2 * sin(t * 2.0 + float(i))
		draw_rect(Rect2(x, y, 1, 1), Color(1, 1, 1, maxf(a, 0.05)))
	# horizon glow
	draw_circle(Vector2(160, 168), 90.0, Color(C_PURPLE.r, C_PURPLE.g, C_PURPLE.b, 0.10))
	draw_circle(Vector2(160, 168), 55.0, Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.09))
	if screen == "main":
		_draw_menu_backdrop()

	match screen:
		"main":
			draw_circle(Vector2(160, 58), 72.0, Color(C_PURPLE.r, C_PURPLE.g, C_PURPLE.b, 0.07))
			draw_circle(Vector2(160, 50), 44.0, Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.06))
			_draw_title()
			draw_string(_font, Vector2(0, 96), "STEAL THEIR BUTTONS. ESCAPE.", HORIZONTAL_ALIGNMENT_CENTER, 320, 7, Color(0.7, 0.72, 0.95, 0.8))
		"levels":
			draw_string(_font, Vector2(0, 24), "SELECT A LEVEL", HORIZONTAL_ALIGNMENT_CENTER, 320, 12, Color(1, 1, 1))
			for row in 3:
				draw_string(_font, Vector2(6, 55 + row * 27), "WORLD %d" % (row + 1), HORIZONTAL_ALIGNMENT_LEFT, 56, 7, Color(0.7, 0.7, 0.95, 0.8))
			draw_string(_font, Vector2(0, 174), "COMPLETED LEVELS UNLOCK THE NEXT ONE", HORIZONTAL_ALIGNMENT_CENTER, 320, 6, Color(0.6, 0.6, 0.8, 0.6))
		"confirm_new":
			draw_string(_font, Vector2(0, 58), "START OVER?", HORIZONTAL_ALIGNMENT_CENTER, 320, 18, C_YELLOW)
			draw_string(_font, Vector2(0, 76), "THIS ERASES LEVEL PROGRESS AND TIMES.", HORIZONTAL_ALIGNMENT_CENTER, 320, 7, Color(1, 0.82, 0.85, 0.95))
			draw_string(_font, Vector2(0, 88), "YOUR SETTINGS ARE KEPT.", HORIZONTAL_ALIGNMENT_CENTER, 320, 7, Color(0.7, 0.72, 0.95, 0.8))
		"controls":
			draw_string(_font, Vector2(0, 34), "CONTROLS", HORIZONTAL_ALIGNMENT_CENTER, 320, 16, C_CYAN)
			_draw_control_rows()
		"credits":
			draw_string(_font, Vector2(0, 34), "CREDITS", HORIZONTAL_ALIGNMENT_CENTER, 320, 16, C_CYAN)
			_draw_credits_rows()
		"settings":
			draw_string(_font, Vector2(0, 54), "SETTINGS", HORIZONTAL_ALIGNMENT_CENTER, 320, 14, Color(1, 1, 1))
			draw_string(_font, Vector2(0, 170), "ALT+ENTER TOGGLES FULLSCREEN ANY TIME", HORIZONTAL_ALIGNMENT_CENTER, 320, 6, Color(0.65, 0.66, 0.85, 0.75))
		"paused":
			draw_rect(Rect2(0, 0, 320, 180), Color(0, 0, 0, 0.55))
			draw_string(_font, Vector2(0, 62), "PAUSED", HORIZONTAL_ALIGNMENT_CENTER, 320, 20, Color(1, 1, 1))
		"complete":
			draw_string(_font, Vector2(0, 56), "LEVEL CLEAR", HORIZONTAL_ALIGNMENT_CENTER, 320, 20, C_GREEN)
			draw_string(_font, Vector2(0, 76), Levels.display_name(_last_index), HORIZONTAL_ALIGNMENT_CENTER, 320, 9, Color(0.85, 0.86, 1.0))
			var ti := int(_complete_time)
			draw_string(_font, Vector2(0, 96), "TIME  %d:%02d" % [ti / 60, ti % 60], HORIZONTAL_ALIGNMENT_CENTER, 320, 8, Color(0.8, 0.85, 1.0, 0.9))
			draw_string(_font, Vector2(0, 110), "COINS %d/%d" % [_complete_coins, _complete_total], HORIZONTAL_ALIGNMENT_CENTER, 320, 8, Color(C_YELLOW))
		"victory":
			draw_rect(Rect2(0, 0, 320, 180), Color(0.03, 0.0, 0.05, 0.9))
			draw_string(_font, Vector2(0, 44), "CONTROLS STOLEN", HORIZONTAL_ALIGNMENT_CENTER, 320, 18, C_PINK)
			draw_string(_font, Vector2(0, 66), "THE CONTROL MASTER IS OFFLINE", HORIZONTAL_ALIGNMENT_CENTER, 320, 8, Color(0.85, 0.9, 1.0))
			draw_string(_font, Vector2(0, 86), "You made your own path.", HORIZONTAL_ALIGNMENT_CENTER, 320, 9, Color(C_CYAN))
			var tv := int(_victory_time)
			draw_string(_font, Vector2(0, 104), "TOTAL TIME  %d:%02d" % [tv / 60, tv % 60], HORIZONTAL_ALIGNMENT_CENTER, 320, 8, Color(0.8, 0.85, 1.0, 0.9))
			var n_ab: int = GameState.ABILITY_ORDER.size()
			var start_x: float = 160.0 - float(n_ab - 1) * 9.5
			for i in n_ab:
				var ab: String = GameState.ABILITY_ORDER[i]
				var c: Color = GameState.color_of(ab)
				Icons.draw_ability(self, ab, Vector2(start_x + i * 19.0, 120), 5.0, c)


## Three parallax city layers plus drifting motes, themed on the game's own
## environments. Pure rect drawing: no textures, no extra nodes, cheap.
func _draw_menu_backdrop() -> void:
	var layers := [
		{"speed": 3.0, "h": 34.0, "col": Color(0.10, 0.08, 0.22, 0.85), "step": 26.0, "base": 176.0},
		{"speed": 7.0, "h": 46.0, "col": Color(0.14, 0.10, 0.28, 0.90), "step": 34.0, "base": 180.0},
		{"speed": 13.0, "h": 58.0, "col": Color(0.19, 0.13, 0.35, 0.95), "step": 44.0, "base": 184.0},
	]
	for li in layers.size():
		var lay: Dictionary = layers[li]
		var step: float = lay["step"]
		var offset := fposmod(t * float(lay["speed"]), step)
		var x := -step + offset
		var idx := 0
		while x < 330.0:
			var seedv := float((idx * 37 + li * 91) % 23)
			var hh: float = float(lay["h"]) * (0.55 + seedv / 40.0)
			var bw: float = step * 0.72
			var top: float = float(lay["base"]) - hh
			var col: Color = lay["col"]
			draw_rect(Rect2(x, top, bw, hh), col)
			# a couple of lit windows so the silhouette reads as a city
			var rows := int(hh / 7.0)
			for r in rows:
				if (r + idx) % 3 != 0:
					continue
				var wy := top + 3.0 + float(r) * 7.0
				draw_rect(Rect2(x + 2.0, wy, 1.5, 2.0), Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.30))
				if bw > 12.0:
					draw_rect(Rect2(x + bw - 5.0, wy, 1.5, 2.0), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.24))
			x += step
			idx += 1
	# warm haze behind the title so text stays readable over the skyline
	draw_circle(Vector2(160, 52), 74.0, Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.05))


func _draw_control_rows() -> void:
	var rows := [
		["D", "MOVE RIGHT", "always yours"],
		["SPACE", "JUMP", "steal from blue"],
		["A", "MOVE LEFT", "steal from green"],
		["X", "DASH", "steal from yellow"],
		["Q", "SPECIAL", "steal from purple"],
		["T", "TIME STEAL", "steal from teal"],
		["E", "STEAL", "takes the nearest"],
		["ESC", "PAUSE", "and back in menus"],
		["ALT+ENTER", "FULLSCREEN", "any time"],
	]
	var y := 50.0
	for r in rows:
		var key: String = r[0]
		var label: String = r[1]
		var note: String = r[2]
		draw_rect(Rect2(28, y - 8, 306, 10), Color(0.09, 0.07, 0.2, 0.55))
		draw_string(_font, Vector2(32, y), key, HORIZONTAL_ALIGNMENT_RIGHT, 44, 7, C_YELLOW)
		draw_string(_font, Vector2(82, y), label, HORIZONTAL_ALIGNMENT_LEFT, 70, 7, Color(0.95, 0.95, 1.0))
		draw_string(_font, Vector2(156, y), note, HORIZONTAL_ALIGNMENT_LEFT, 170, 7, Color(0.62, 0.66, 0.88, 0.85))
		y += 11.0
	draw_string(_font, Vector2(0, 146), "ABILITIES ARE STOLEN, NEVER GIVEN.", HORIZONTAL_ALIGNMENT_CENTER, 320, 6, Color(1, 0.42, 0.68, 0.85))


func _draw_credits_rows() -> void:
	var lines := [
		["STEAL THE CONTROL", C_PINK, 12],
		["A 2D PIXEL PLATFORMER ABOUT BORROWED MOVEMENT", Color(0.85, 0.88, 1.0), 7],
		["", Color.WHITE, 6],
		["ART, CODE AND SOUND ARE ORIGINAL AND PROCEDURAL", Color(0.72, 0.78, 1.0), 7],
		["NOTHING IS TAKEN FROM ANOTHER GAME", Color(0.72, 0.78, 1.0), 7],
		["", Color.WHITE, 6],
		["BUILT WITH SUMMER ENGINE", C_CYAN, 8],
		["GODOT 4 RENDERING PIPELINE", Color(0.6, 0.64, 0.86), 7],
		["", Color.WHITE, 6],
		["THANK YOU FOR PLAYING", C_GREEN, 9],
	]
	var y := 56.0
	for l in lines:
		var text: String = l[0]
		if text != "":
			draw_string(_font, Vector2(0, y), text, HORIZONTAL_ALIGNMENT_CENTER, 320, int(l[2]), l[1])
		y += 11.0


func _draw_title() -> void:
	var bob := sin(t * 1.4) * 1.4
	_title_line("STEAL", 44.0 + bob, 40, Color(1, 1, 1))
	_title_line("THE", 62.0 + bob, 12, C_CYAN)
	_title_line("CONTROLS", 84.0 + bob, 26, C_PINK)
	# diorama: our robot on the left, the blue jumper on the right
	_menu_robot(34.0, 96.0)
	_menu_enemy(286.0, 100.0)
	var n_ab: int = GameState.ABILITY_ORDER.size()
	for i in n_ab:
		var ab: String = GameState.ABILITY_ORDER[i]
		var c: Color = GameState.color_of(ab)
		var owned: bool = GameState.has(ab)
		var cc := c if owned else Color(c.r, c.g, c.b, 0.35)
		Icons.draw_ability(self, ab, Vector2(300.0, 30.0 + float(i) * 11.0), 3.4, cc)


func _title_line(text: String, y: float, size: int, col: Color) -> void:
	draw_string(_font, Vector2(0, y + 2.0), text, HORIZONTAL_ALIGNMENT_CENTER, 320, size, Color(0, 0, 0, 0.55))
	draw_string(_font, Vector2(0, y), text, HORIZONTAL_ALIGNMENT_CENTER, 320, size, col)


func _menu_robot(x: float, y: float) -> void:
	var float_y := y + sin(t * 2.0) * 1.2
	draw_rect(Rect2(x - 16, float_y + 4, 32, 3), Color(0.25, 0.18, 0.45, 0.8))
	draw_rect(Rect2(x - 14, float_y + 7, 28, 2), Color(0.14, 0.09, 0.28, 0.9))
	draw_rect(Rect2(x - 9, float_y - 12, 18, 17), Color(0.05, 0.04, 0.12))
	draw_rect(Rect2(x - 8, float_y - 11, 16, 15), Color(0.97, 0.97, 1.0))
	draw_rect(Rect2(x - 8, float_y, 16, 4), Color(0.72, 0.74, 0.94))
	var blink := 1.0 if fposmod(t, 3.4) > 0.16 else 0.25
	draw_rect(Rect2(x - 5, float_y - 8, 3, 4.0 * blink), Color(0.06, 0.05, 0.14))
	draw_rect(Rect2(x + 2, float_y - 8, 3, 4.0 * blink), Color(0.06, 0.05, 0.14))
	draw_rect(Rect2(x - 1, float_y - 3, 2, 1), Color(0.06, 0.05, 0.14))
	# floating jump button it is trying to steal
	var jy := float_y - 30.0 + sin(t * 3.0) * 2.0
	draw_rect(Rect2(x + 10, jy - 6, 14, 13), Color(0.06, 0.05, 0.14, 0.9))
	draw_rect(Rect2(x + 11, jy - 5, 12, 11), Color(0.21, 0.79, 1.0, 0.9))
	Icons.draw_ability(self, "jump", Vector2(x + 17, jy), 3.0, Color(1, 1, 1, 0.95))


func _menu_enemy(x: float, y: float) -> void:
	var float_y := y + sin(t * 2.0 + 1.2) * 1.6
	draw_rect(Rect2(x - 16, float_y + 4, 32, 3), Color(0.25, 0.18, 0.45, 0.8))
	draw_rect(Rect2(x - 14, float_y + 7, 28, 2), Color(0.14, 0.09, 0.28, 0.9))
	draw_rect(Rect2(x - 8, float_y - 12, 16, 16), Color(0.04, 0.05, 0.12))
	draw_rect(Rect2(x - 7, float_y - 11, 14, 14), Color(0.24, 0.48, 1.0))
	draw_rect(Rect2(x - 7, float_y - 11, 14, 1), Color(0.55, 0.75, 1.0))
	draw_rect(Rect2(x - 6, float_y - 8, 12, 4), Color(0.05, 0.04, 0.11))
	draw_rect(Rect2(x - 4, float_y - 7, 3, 2), Color(0.3, 0.85, 1.0))
	draw_rect(Rect2(x + 1, float_y - 7, 3, 2), Color(0.3, 0.85, 1.0))
	draw_rect(Rect2(x - 5, float_y + 1, 3, 2), Color(0.1, 0.2, 0.5))
	draw_rect(Rect2(x + 2, float_y + 1, 3, 2), Color(0.1, 0.2, 0.5))
	draw_rect(Rect2(x - 0.5, float_y - 16, 1, 4), Color(0.06, 0.05, 0.14))
	draw_circle(Vector2(x, float_y - 17), 2.0, Color(0.3, 0.85, 1.0))
