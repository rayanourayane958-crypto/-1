extends Node2D
class_name ControlMaster
## THE CONTROL MASTER - three phase boss.
## Float + fire -> telegraph -> slam -> stunned window in which the player
## stomps its glowing cores.

signal defeated
signal health_changed(current: int, max_health: int)
signal phase_changed(phase: int)

const MAX_HP := 9
const GROUND_Y := 0.0

var hp := MAX_HP
var phase := 1
var defeated_state := false
var state := "float"
var timer := 1.6
var y_off := -46.0
var base_y := 0.0
var flash := 0.0
var t := 0.0
var shoot_timer := 1.2
var lock_timer := 5.0
var projectiles: Array = []
var player: Player = null
var shake := 0.0
var locks := {}
var announcing := 0.0


func _ready() -> void:
	z_index = 4
	base_y = position.y
	player = get_tree().get_first_node_in_group("player") as Player
	health_changed.emit(hp, MAX_HP)
	Sfx.play("alert", 0.7)


func _physics_process(delta: float) -> void:
	if defeated_state:
		return
	t += delta
	flash = maxf(flash - delta, 0.0)
	announcing = maxf(announcing - delta, 0.0)
	_update_locks(delta)
	_tick_projectiles(delta)
	if player == null or not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player") as Player
		return

	match state:
		"float":
			_move_float(delta)
			_shoot(delta)
			_phase_actions(delta)
			timer -= delta
			if timer <= 0.0:
				state = "telegraph"
				timer = 0.8
				Sfx.play("alert", 0.8)
		"telegraph":
			y_off = lerpf(y_off, -58.0, clampf(delta * 6.0, 0.0, 1.0))
			timer -= delta
			if timer <= 0.0:
				state = "slam"
				timer = 1.6
				Sfx.play("special", 0.6)
		"slam":
			y_off = move_toward(y_off, 0.0, 420.0 * delta)
			timer -= delta
			if y_off >= -1.0:
				state = "stun"
				timer = 1.7
				shake = 6.0
				Sfx.play("dash", 0.5)
		"stun":
			timer -= delta
			if timer <= 0.0:
				state = "float"
				timer = 2.0
				shoot_timer = 0.6
	position.y = base_y + y_off
	queue_redraw()


func _move_float(delta: float) -> void:
	var target_x := position.x
	if player != null:
		target_x = lerpf(position.x, player.global_position.x + (24.0 if position.x > player.global_position.x else -24.0), delta * 0.6)
	position.x = clampf(target_x, 220.0, 800.0)
	y_off = lerpf(y_off, -46.0 + sin(t * 2.0) * 5.0, clampf(delta * 3.0, 0.0, 1.0))


func _shoot(delta: float) -> void:
	shoot_timer -= delta
	if shoot_timer > 0.0:
		return
	shoot_timer = [1.3, 0.95, 0.62][phase - 1]
	var count: int = [1, 2, 3][phase - 1]
	for i in count:
		var dir := -1.0 if player.global_position.x < global_position.x else 1.0
		var spread := (float(i) - float(count - 1) * 0.5) * 26.0
		projectiles.append({
			"pos": Vector2(0, -26),
			"vel": Vector2(dir * 110.0, spread),
			"life": 4.0,
		})
	Sfx.play("alert", 1.1)


func _tick_projectiles(delta: float) -> void:
	if player == null:
		return
	var keep: Array = []
	for p in projectiles:
		p["pos"] += p["vel"] * delta
		p["life"] -= delta
		var world: Vector2 = global_position + p["pos"]
		if world.distance_to(player.global_position) < 12.0:
			player.kill()
			continue
		if float(p["life"]) > 0.0 and world.x > 0.0 and world.y > -200.0:
			keep.append(p)
	projectiles = keep


func _phase_actions(delta: float) -> void:
	lock_timer -= delta
	if lock_timer > 0.0:
		return
	lock_timer = 5.5 if phase == 1 else 4.5
	if phase == 1:
		var options := ["jump", "left"]
		_lock(String(options[randi() % options.size()]), 3.0)
	elif phase == 2:
		var options2 := ["dash", "gravity", "jump"]
		_lock(String(options2[randi() % options2.size()]), 3.4)
	else:
		var options3 := ["dash", "gravity", "left"]
		_lock(String(options3[randi() % options3.size()]), 3.0)


func _lock(ability: String, duration: float) -> void:
	if not GameState.has(ability):
		return
	if GameState.take(ability):
		locks[ability] = duration
		Sfx.play("drain")
		announcing = 0.9


func _update_locks(delta: float) -> void:
	var done: Array = []
	for a in locks.keys():
		locks[a] = float(locks[a]) - delta
		if float(locks[a]) <= 0.0:
			done.append(a)
	for a in done:
		locks.erase(a)
		GameState.grant(String(a))


func restore_all_locks() -> void:
	for a in locks.keys():
		GameState.grant(String(a))
	locks.clear()


func _check_stomp() -> bool:
	if player == null:
		return false
	if state != "stun":
		return false
	var prect := Rect2(player.global_position.x - 5.0, player.global_position.y - 14.0, 10.0, 16.0)
	var body_rect := Rect2(global_position.x - 34.0, global_position.y + y_off - 44.0, 68.0, 50.0)
	return prect.intersects(body_rect)


func _unhandled_input(_e: InputEvent) -> void:
	pass


func take_hit() -> void:
	if defeated_state:
		return
	if not _check_stomp():
		return
	hp -= 1
	flash = 0.35
	shake = 5.0
	Sfx.play("coin", 0.6)
	player.velocity.y = -250.0 * player.gravity_sign
	health_changed.emit(hp, MAX_HP)
	var new_phase := 1
	if hp <= 0:
		new_phase = 3
	elif hp <= 3:
		new_phase = 3
	elif hp <= 6:
		new_phase = 2
	if hp <= 0:
		_die()
		return
	if new_phase != phase:
		phase = new_phase
		timer = 1.4
		state = "float"
		y_off = -52.0
		phase_changed.emit(phase)
		Sfx.play("steal")
	# short stun then resume
	state = "stun"
	timer = 0.55


func _die() -> void:
	defeated_state = true
	projectiles.clear()
	restore_all_locks()
	queue_redraw()
	Sfx.play("exit")
	var tw := create_tween()
	tw.tween_property(self, "modulate", Color(3, 3, 4, 1), 0.12)
	tw.tween_property(self, "modulate", Color(1, 1, 1, 1), 0.12)
	tw.tween_property(self, "modulate:a", 0.0, 0.7)
	tw.tween_callback(_finish_defeat)


func _finish_defeat() -> void:
	defeated.emit()
	visible = false


func _draw() -> void:
	var bob := y_off
	var pulse := 0.5 + 0.5 * sin(t * 4.0)
	var body_col := Color("3b2a63") if phase < 3 else Color("5a1f3f")
	var glow := Color("ff4fa3") if phase == 1 else (Color("ffd233") if phase == 2 else Color("ff3b3b"))
	# legs / hover thruster
	draw_rect(Rect2(-22, 4, 44, 8), Color("1a1130"))
	draw_rect(Rect2(-16, 10, 32, 4), Color(glow.r, glow.g, glow.b, 0.5))
	# body
	draw_rect(Rect2(-34, -44, 68, 50), Color("0f0a20"))
	draw_rect(Rect2(-32, -42, 64, 46), body_col)
	draw_rect(Rect2(-32, -42, 64, 6), body_col.lightened(0.25))
	draw_rect(Rect2(-32, 0, 64, 4), Color("0f0a20"))
	# cockpit eye
	var eye_w := 30.0 + pulse * 4.0
	draw_rect(Rect2(-eye_w * 0.5, -32, eye_w, 14), Color("0a0616"))
	draw_rect(Rect2(-eye_w * 0.5 + 3, -29, eye_w - 6, 8), Color(glow.r, glow.g, glow.b, 0.85))
	var look := 0.0
	if player != null:
		look = clampf((player.global_position.x - global_position.x) * 0.04, -6.0, 6.0)
	draw_rect(Rect2(-3 + look, -29, 6, 8), Color(1, 1, 1, 0.95))
	# cores
	for i in 3:
		var cx := -22.0 + float(i) * 22.0
		var alive_core := hp > (2 - i) * 3
		var c := glow if alive_core else Color("2a2038")
		var r := 7.0 + (sin(t * 6.0 + float(i)) * 1.5 if alive_core else 0.0)
		draw_circle(Vector2(cx, -8), r + 2.0, Color("0a0616"))
		draw_circle(Vector2(cx, -8), r, c)
		if alive_core:
			draw_circle(Vector2(cx, -8), r * 0.45, Color(1, 1, 1, 0.75 + pulse * 0.25))
	# arms
	draw_rect(Rect2(-46, -36, 12, 10), body_col.darkened(0.2))
	draw_rect(Rect2(34, -36, 12, 10), body_col.darkened(0.2))
	# antenna
	draw_rect(Rect2(-2, -52, 4, 10), Color("1a1130"))
	draw_circle(Vector2(0, -54), 4.0, glow)
	# telegraph + stun cues
	if state == "telegraph":
		draw_arc(Vector2.ZERO, 52.0, 0, TAU, 28, Color(1, 0.35, 0.4, 0.5 + pulse * 0.4), 2.0)
	elif state == "stun":
		draw_arc(Vector2.ZERO, 50.0, 0, TAU, 28, Color(1, 1, 0.6, 0.55 + pulse * 0.35), 2.0)
	if flash > 0.0:
		draw_rect(Rect2(-32, -42, 64, 46), Color(1, 1, 1, flash * 2.0))
	# projectiles
	for p in projectiles:
		var pos: Vector2 = p["pos"]
		draw_circle(pos, 6.0, Color("0a0616"))
		draw_circle(pos, 4.5, glow)
		draw_circle(pos, 1.8, Color(1, 1, 1, 0.9))
	if announcing > 0.0:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
