extends Node2D
class_name LevelBuilder
## Builds a level from its data dictionary at runtime and runs its logic.

signal exit_reached
signal coins_changed(taken: int, total: int)
signal checkpoint_set(pos: Vector2)
signal boss_defeated
signal ability_drained(ability: String)

const T := 16.0

var data: Dictionary = {}
var player: Player = null
var bounds := Vector2.ZERO
var spawn_pos := Vector2.ZERO
var checkpoint_pos := Vector2.ZERO
var coins_total := 0
var coins_taken := 0
var time := 0.0
var running := false
var finished := false
var enemies: Array[Enemy] = []
var doors: Array = []
var conveyors: Array = []
var movers: Array = []
var spike_rects: Array[Rect2] = []
var coins: Array = []
var exit_node: Node2D = null
var boss: ControlMaster = null


func build(d: Dictionary, p: Player) -> void:
	data = d
	player = p
	bounds = Levels.size_of(d)
	for c in get_children():
		c.queue_free()
	enemies.clear()
	doors.clear()
	conveyors.clear()
	movers.clear()
	spike_rects.clear()
	coins.clear()
	coins_total = 0
	coins_taken = 0
	time = 0.0
	finished = false

	var sp: Array = d.get("spawn", [2, 11])
	spawn_pos = Vector2(float(sp[0]) * T + 8.0, float(sp[1]) * T + 8.0)
	checkpoint_pos = spawn_pos

	_build_solids(d.get("solids", []))
	_build_spikes(d.get("spikes", []))
	_build_conveyors(d.get("conveyors", []))
	_build_doors(d.get("doors", []))
	_build_movers(d.get("movers", []))
	_build_coins(d.get("coins", []))
	_build_checkpoints(d.get("checkpoints", []))
	_build_exit(d.get("exit", [50, 11]))
	_build_enemies(d.get("enemies", []))
	if bool(d.get("boss", false)):
		_build_boss()

	coins_changed.emit(0, coins_total)


func _wall_colors() -> Array:
	match int(data.get("world", 1)):
		2:
			return [Color("241a3f"), Color("453466")]
		3:
			return [Color("1c1030"), Color("3c2357")]
	return [Color("26214d"), Color("453a78")]


func _build_solids(list: Array) -> void:
	var cols := _wall_colors()
	for s in list:
		var w := float(s[2]) * T
		var h := float(s[3]) * T
		var body := StaticBody2D.new()
		body.position = Vector2(float(s[0]) * T, float(s[1]) * T)
		var cs := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(w, h)
		cs.shape = shape
		cs.position = Vector2(w * 0.5, h * 0.5)
		body.add_child(cs)
		var vr := VisualRect.new()
		vr.kind = "block"
		vr.size = Vector2(w, h)
		vr.fill = cols[0]
		vr.edge = cols[1]
		body.add_child(vr)
		add_child(body)


## Nearest solid surface to a hint y, so spikes, checkpoints and exits always
## sit exactly on the floor they belong to. tops_only ignores ceilings, which
## keeps respawn points on ground the player can actually stand on.
func _surface_near(x: float, y_hint: float, tops_only: bool = false) -> float:
	var best := y_hint
	var best_d := -1.0
	for s in data.get("solids", []):
		var left := float(s[0]) * T
		var right := left + float(s[2]) * T
		if x < left - 1.0 or x > right + 1.0:
			continue
		var top := float(s[1]) * T
		var bottom := top + float(s[3]) * T
		var candidates: Array = [top]
		if not tops_only:
			candidates.append(bottom)
		for surf in candidates:
			var d: float = absf(float(surf) - y_hint)
			if best_d < 0.0 or d < best_d:
				best_d = d
				best = float(surf)
	return best


func _build_spikes(list: Array) -> void:
	for s in list:
		var w := float(s[2]) * T
		var x := float(s[0]) * T
		var floor_y := _surface_near(x + w * 0.5, float(s[1]) * T + 12.0)
		var r := Rect2(x, floor_y - 12.0, w, 12.0)
		spike_rects.append(r)
		var vr := VisualRect.new()
		vr.kind = "spike"
		vr.size = Vector2(w, 12.0)
		vr.position = r.position
		add_child(vr)


func _build_conveyors(list: Array) -> void:
	for c in list:
		var cw := float(c["w"]) * T
		var cx := float(c["x"]) * T
		var floor_y := _surface_near(cx + cw * 0.5, float(c["y"]) * T + 12.0)
		var r := Rect2(cx, floor_y - 12.0, cw, 12.0)
		var dir := int(c.get("dir", 1))
		conveyors.append({"rect": r, "dir": dir})
		var vr := VisualRect.new()
		vr.kind = "conveyor"
		vr.size = Vector2(r.size.x, r.size.y)
		vr.position = r.position
		vr.direction = dir
		add_child(vr)


func _build_doors(list: Array) -> void:
	for d in list:
		var w := float(d["w"]) * T
		var h := float(d["h"]) * T
		var body := StaticBody2D.new()
		body.position = Vector2(float(d["x"]) * T, float(d["y"]) * T)
		var cs := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(w, h)
		cs.shape = shape
		cs.position = Vector2(w * 0.5, h * 0.5)
		body.add_child(cs)
		var vr := VisualRect.new()
		vr.kind = "door"
		vr.size = Vector2(w, h)
		vr.accent = Color("ff4fa3")
		body.add_child(vr)
		add_child(body)
		doors.append({
			"body": body,
			"shape": cs,
			"vis": vr,
			"requires": d.get("requires", []),
			"timer": float(d.get("timer", 0.0)),
			"open_time": float(d.get("open", 1.6)),
			"clock": 0.0,
			"open": false,
		})


func _build_movers(list: Array) -> void:
	for m in list:
		var w := float(m["w"]) * T
		var body := AnimatableBody2D.new()
		body.sync_to_physics = true
		body.position = Vector2(float(m["x"]) * T, float(m["y"]) * T)
		var cs := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(w, 12.0)
		cs.shape = shape
		cs.position = Vector2(w * 0.5, 6.0)
		body.add_child(cs)
		var vr := VisualRect.new()
		vr.kind = "mover"
		vr.size = Vector2(w, 12.0)
		vr.accent = Color("ffd233")
		body.add_child(vr)
		add_child(body)
		movers.append({
			"body": body,
			"from": Vector2(float(m["x"]) * T, float(m["y"]) * T),
			"to": Vector2(float(m.get("to_x", m["x"])) * T, float(m.get("to_y", m["y"])) * T),
			"speed": float(m.get("speed", 40.0)),
			"w": w,
			"t": 0.0,
			"dir": 1.0,
		})


func _build_coins(list: Array) -> void:
	for c in list:
		var n := VisualRect.new()
		n.kind = "coin"
		n.position = Vector2(float(c[0]) * T + 8.0, float(c[1]) * T + 8.0)
		n.star_phase = randf() * TAU
		add_child(n)
		coins.append({"node": n, "pos": n.position, "taken": false})
		coins_total += 1


func _build_checkpoints(list: Array) -> void:
	for c in list:
		var x := float(c[0]) * T + 8.0
		var base_y := _surface_near(x, float(c[1]) * T + 8.0, true)  # tops only: respawn always restores normal gravity
		var n := VisualRect.new()
		n.kind = "checkpoint"
		n.position = Vector2(x, base_y)
		add_child(n)
		n.set_meta("is_check", true)
		n.set_meta("pos", Vector2(x, base_y))


## Static safety analysis for every checkpoint in a level definition.
## Returns one entry per checkpoint: {"index", "pos", "standable", "issues"}.
## Powers the headless checkpoint tests and lets level data be validated without
## booting the game. Issues found: spike_overlap, spike_too_close, inside_door,
## enemy_patrol, mover_path, inside_solid, no_ground.
static func checkpoint_safety(d: Dictionary) -> Array:
	var out: Array = []
	var solids := _solid_rects(d)
	var spikes := _spike_rects(d)
	var doors := _door_rects(d)
	var list: Array = d.get("checkpoints", [])
	for i in list.size():
		var c: Array = list[i]
		var x := float(c[0]) * T + 8.0
		var y_hint := float(c[1]) * T + 8.0
		var issues: Array = []

		# Snap to the nearest floor TOP under the hint, mirroring the builder.
		var top_y := -1.0
		var grounded := false
		var best_d := -1.0
		for s in solids:
			if x < s.position.x - 1.0 or x > s.position.x + s.size.x + 1.0:
				continue
			var dist: float = absf(s.position.y - y_hint)
			if best_d < 0.0 or dist < best_d:
				best_d = dist
				top_y = s.position.y
				grounded = true
		if not grounded:
			issues.append("no_ground")
			top_y = y_hint

		var body := Rect2(x - 5.0, top_y - 14.0, 10.0, 16.0)
		# torso excludes the floor contact so standing on ground is never "inside".
		var torso := Rect2(x - 5.0, top_y - 14.0, 10.0, 13.0)

		for r in spikes:
			if body.intersects(r):
				issues.append("spike_overlap")
				break
			elif body.grow(10.0).intersects(r):
				issues.append("spike_too_close")
				break
		for r in doors:
			if body.intersects(r):
				issues.append("inside_door")
				break
		for r in solids:
			if r.intersects(torso):
				issues.append("inside_solid")
				break

		# Enemy patrol sweeps: 3 tiles each way, plus the body half width.
		for e in d.get("enemies", []):
			var kind := String(e[0])
			var home := Vector2(float(e[1]) * T + 8.0, float(e[2]) * T + 8.0)
			var e_y := home.y
			if kind == "purple":
				e_y = _ceiling_near(solids, home.x, home.y)
			elif kind == "teal":
				e_y = home.y - 12.0
			else:
				# ground walkers slide down to their floor before they patrol
				e_y = _floor_top_below(solids, home.x, home.y)
			var patrol := Rect2(home.x - 54.0, e_y - 12.0, 108.0, 12.0)
			if patrol.intersects(body.grow(4.0)):
				issues.append("enemy_patrol")
				break

		# Moving platforms sweep their whole path through the respawn spot.
		for m in d.get("movers", []):
			var mw := float(m["w"]) * T
			var a := Vector2(float(m["x"]) * T, float(m["y"]) * T)
			var b := Vector2(float(m.get("to_x", m["x"])) * T, float(m.get("to_y", m["y"])) * T)
			var swept := Rect2(
				minf(a.x, b.x), minf(a.y, b.y),
				absf(b.x - a.x) + mw, absf(b.y - a.y) + 12.0)
			if swept.grow(2.0).intersects(body):
				issues.append("mover_path")
				break

		out.append({
			"index": i,
			"pos": Vector2(x, top_y),
			"standable": grounded,
			"issues": issues,
		})
	return out


static func _solid_rects(d: Dictionary) -> Array:
	var out: Array = []
	for s in d.get("solids", []):
		out.append(Rect2(float(s[0]) * T, float(s[1]) * T, float(s[2]) * T, float(s[3]) * T))
	return out


static func _spike_rects(d: Dictionary) -> Array:
	var out: Array = []
	var solids := _solid_rects(d)
	for s in d.get("spikes", []):
		var w := float(s[2]) * T
		var x := float(s[0]) * T
		var hint := float(s[1]) * T + 12.0
		var mid := x + w * 0.5
		var floor_y := hint
		var best := -1.0
		for r in solids:
			if mid < r.position.x - 1.0 or mid > r.position.x + r.size.x + 1.0:
				continue
			for surf in [r.position.y, r.position.y + r.size.y]:
				var dist: float = absf(float(surf) - hint)
				if best < 0.0 or dist < best:
					best = dist
					floor_y = float(surf)
		out.append(Rect2(x, floor_y - 12.0, w, 12.0))
	return out


static func _door_rects(d: Dictionary) -> Array:
	var out: Array = []
	for gate in d.get("doors", []):
		out.append(Rect2(
			float(gate["x"]) * T, float(gate["y"]) * T,
			float(gate["w"]) * T, float(gate["h"]) * T))
	return out


## First solid top at or below y, i.e. the floor a ground walker settles onto.
static func _floor_top_below(solids: Array, x: float, y: float) -> float:
	var best := -1.0
	for r in solids:
		if x < r.position.x - 1.0 or x > r.position.x + r.size.x + 1.0:
			continue
		var top: float = r.position.y
		if top < y - 2.0:
			continue
		if best < 0.0 or top < best:
			best = top
	return best if best >= 0.0 else y


static func _ceiling_near(solids: Array, x: float, y_hint: float) -> float:
	var best := y_hint
	var best_d := -1.0
	for r in solids:
		if x < r.position.x - 1.0 or x > r.position.x + r.size.x + 1.0:
			continue
		var surf: float = r.position.y + r.size.y
		var dist: float = absf(surf - y_hint)
		if best_d < 0.0 or dist < best_d:
			best_d = dist
			best = surf
	return best


func _build_exit(pos: Array) -> void:
	var x := float(pos[0]) * T + 8.0
	var base_y := _surface_near(x, float(pos[1]) * T + 8.0)
	var n := VisualRect.new()
	n.kind = "exit"
	n.position = Vector2(x, base_y)
	add_child(n)
	exit_node = n


func _build_enemies(list: Array) -> void:
	for e in list:
		var kind := String(e[0])
		var en := Enemy.new()
		en.kind = kind
		en.collision_layer = 4
		en.collision_mask = 1
		en.position = Vector2(float(e[1]) * T + 8.0, float(e[2]) * T + 8.0)
		var cs := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(12, 12)
		cs.shape = shape
		cs.position = Vector2(0, -6)
		en.add_child(cs)
		en.player_stolen.connect(_on_player_stolen)
		add_child(en)
		enemies.append(en)


func _build_boss() -> void:
	var b: ControlMaster = preload("res://scripts/boss.gd").new()
	b.position = Vector2(42 * T, 13 * T - 4.0)
	add_child(b)
	boss = b
	b.defeated.connect(_on_boss_defeated)


func _on_boss_defeated() -> void:
	boss_defeated.emit()


func _on_player_stolen(ab: String) -> void:
	ability_drained.emit(ab)


func _physics_process(delta: float) -> void:
	if player == null:
		return
	if running and not finished:
		time += delta
	_tick_doors(delta)
	_tick_movers(delta)
	_tick_conveyors(delta)
	_check_coins()
	_check_checkpoints()
	_check_hazards()
	_check_enemies()
	_check_boss()
	_check_exit()


func _check_boss() -> void:
	if boss != null and is_instance_valid(boss) and not boss.defeated_state:
		boss.take_hit()


func _tick_doors(delta: float) -> void:
	for d in doors:
		var want_open := false
		var req: Array = d["requires"]
		if req.size() > 0:
			want_open = true
			for a in req:
				if not GameState.has(String(a)):
					want_open = false
		if float(d["timer"]) > 0.0:
			d["clock"] = fmod(float(d["clock"]) + delta, float(d["timer"]))
			want_open = float(d["clock"]) < float(d["open_time"])
		if want_open != bool(d["open"]):
			d["open"] = want_open
			var body: StaticBody2D = d["body"]
			var shape: CollisionShape2D = d["shape"]
			shape.disabled = want_open
			body.collision_layer = 0 if want_open else 1
		var vis: VisualRect = d["vis"]
		var target := 0.82 if bool(d["open"]) else 0.0
		vis.opened = lerpf(vis.opened, target, clampf(delta * 8.0, 0.0, 1.0))


func _tick_movers(delta: float) -> void:
	# TIME STEAL slows hazards and platforms along with the enemies.
	delta *= GameState.time_factor()
	for m in movers:
		var body: AnimatableBody2D = m["body"]
		var from: Vector2 = m["from"]
		var to: Vector2 = m["to"]
		var speed: float = m["speed"]
		var dist := from.distance_to(to)
		if dist < 1.0:
			continue
		var dirn: float = float(m["dir"])
		var pos := body.position + (to - from).normalized() * speed * dirn * delta
		var prog := (pos - from).dot((to - from).normalized()) / dist
		if prog >= 1.0:
			pos = to
			m["dir"] = -1.0
		elif prog <= 0.0:
			pos = from
			m["dir"] = 1.0
		body.position = pos


func _tick_conveyors(delta: float) -> void:
	if player == null:
		return
	var prect := Rect2(player.global_position.x - 5.0, player.global_position.y - 14.0, 10.0, 16.0)
	for c in conveyors:
		var r: Rect2 = c["rect"]
		if prect.intersects(r):
			player.velocity.x += float(c["dir"]) * 90.0 * delta


func _check_coins() -> void:
	if player == null:
		return
	var ppos: Vector2 = player.global_position
	for c in coins:
		if bool(c["taken"]):
			continue
		var node: Node2D = c["node"]
		if ppos.distance_to(c["pos"] + Vector2(0, -10)) < 16.0:
			c["taken"] = true
			coins_taken += 1
			Sfx.play("coin")
			coins_changed.emit(coins_taken, coins_total)
			var tw := node.create_tween()
			tw.tween_property(node, "scale", Vector2(1.8, 1.8), 0.12)
			tw.parallel().tween_property(node, "modulate:a", 0.0, 0.18)
			tw.tween_callback(node.queue_free)


func _check_checkpoints() -> void:
	var ppos: Vector2 = player.global_position
	for n in get_children():
		if not n.has_meta("is_check") or bool(n.get_meta("active", false)):
			continue
		var cpos: Vector2 = n.get_meta("pos")
		if absf(ppos.x - cpos.x) < 22.0 and ppos.y > cpos.y - 38.0 and ppos.y < cpos.y + 10.0:
			n.set_meta("active", true)
			var vr := n as VisualRect
			if vr != null:
				vr.active = true
				vr.burst = 1.0
			checkpoint_pos = Vector2(cpos.x, cpos.y - 4.0)
			Sfx.play("save")
			checkpoint_set.emit(checkpoint_pos)


func _check_hazards() -> void:
	var ppos: Vector2 = player.global_position
	if ppos.y > bounds.y + 60.0 or ppos.y < -140.0:
		player.kill()
		return
	var prect := Rect2(ppos.x - 5.0, ppos.y - 14.0, 10.0, 16.0)
	for r in spike_rects:
		if prect.intersects(r):
			player.kill()
			return


func _check_enemies() -> void:
	var ppos: Vector2 = player.global_position
	var pvel: Vector2 = player.velocity
	var prect := Rect2(ppos.x - 5.0, ppos.y - 14.0, 10.0, 16.0)
	var falling: bool = pvel.y * player.gravity_sign > 20.0
	for e in enemies:
		if not is_instance_valid(e) or not e.alive or e.stun_time > 0.0:
			continue
		var er := Rect2(e.global_position.x - 6.0, e.global_position.y - 12.0, 12.0, 12.0)
		if not prect.intersects(er):
			continue
		var from_above: bool = prect.position.y + prect.size.y <= er.position.y + 7.0
		if falling and from_above:
			var carried: String = e.target_ability()
			if carried != "" and not GameState.has(carried):
				GameState.grant(carried)
				player.stole.emit(carried)
			if e.kind == "red":
				e.stolen_from_player = ""
			elif e.ability != "":
				e.carry = false
			e.damage()
			player.velocity.y = -250.0 * player.gravity_sign
			Sfx.play("coin", 0.7)
		elif player.invuln <= 0.0:
			player.kill()
			return


func _check_exit() -> void:
	if finished or exit_node == null:
		return
	if boss != null and is_instance_valid(boss) and not boss.defeated_state:
		return
	var gate := Rect2(exit_node.position.x - 16.0, exit_node.position.y - 34.0, 32.0, 36.0)
	if gate.has_point(player.global_position):
		finished = true
		running = false
		Sfx.play("exit")
		exit_reached.emit()


## Called on respawn: shove nearby enemies away and stun them briefly so the
## player is never damaged the instant they reappear.
func guard_spawn(pos: Vector2, radius: float = 64.0) -> void:
	for e in enemies:
		if not is_instance_valid(e) or not e.alive:
			continue
		var d: Vector2 = e.global_position - pos
		if d.length() > radius:
			continue
		e.stun_time = maxf(e.stun_time, 1.2)
		var dir_x := signf(d.x)
		if dir_x == 0.0:
			dir_x = 1.0
		e.velocity.x = dir_x * 130.0
		e.velocity.y = -60.0 * e.gravity_sign


func restore_enemies() -> void:
	for e in enemies:
		if not is_instance_valid(e):
			continue
		if e.kind == "red":
			e.stolen_from_player = ""
		elif e.ability != "":
			e.carry = true
