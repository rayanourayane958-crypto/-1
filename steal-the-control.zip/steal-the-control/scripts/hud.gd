extends Control
class_name GameHUD
## In-game HUD drawn procedurally at the 320x180 design resolution.

var player_node: Player = null
var level_node: LevelBuilder = null
var boss_node: ControlMaster = null
var coins_taken := 0
var coins_total := 0
var elapsed := 0.0
var hint_text := ""
var hint_timer := 0.0
var toast_text := ""
var toast_color := Color.WHITE
var toast_timer := 0.0
var damage_flash := 0.0
var t := 0.0
var level_title := ""
var prompt_ability := ""
var boss_hp := 0
var boss_max := 1
var boss_phase := 1
var show_timer_text := true
var _font: Font = null
const KEYS := {"right": "D", "jump": "SP", "left": "A", "dash": "X", "gravity": "Q", "time": "T"}


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = ThemeDB.fallback_font
	t = 0.0


func attach(p: Player, lvl: LevelBuilder, title: String) -> void:
	player_node = p
	level_node = lvl
	level_title = title
	coins_taken = 0
	coins_total = 0
	elapsed = 0.0
	hint_timer = 5.5
	toast_timer = 0.0
	damage_flash = 0.0
	boss_node = null


func show_hint(text: String, seconds: float = 5.5) -> void:
	hint_text = text
	hint_timer = seconds


func set_progress(taken: int, total: int) -> void:
	coins_taken = taken
	coins_total = total


func set_boss(b: ControlMaster) -> void:
	boss_node = b
	if b != null:
		boss_hp = b.hp
		boss_max = b.MAX_HP
		boss_phase = b.phase


func show_toast(text: String, col: Color) -> void:
	toast_text = text
	toast_color = col
	toast_timer = 1.4


func flash_damage() -> void:
	damage_flash = 0.5


func _process(delta: float) -> void:
	t += delta
	if level_node != null and is_instance_valid(level_node):
		elapsed = level_node.time
	if hint_timer > 0.0:
		hint_timer -= delta
	if toast_timer > 0.0:
		toast_timer -= delta
	damage_flash = maxf(damage_flash - delta, 0.0)
	prompt_ability = ""
	if player_node != null and is_instance_valid(player_node) and player_node.alive and player_node.control_enabled:
		var e = player_node.nearest_stealable()
		if e != null:
			prompt_ability = e.target_ability()
	if boss_node != null and is_instance_valid(boss_node):
		boss_hp = boss_node.hp
		boss_phase = boss_node.phase
	queue_redraw()


func _label(pos: Vector2, text: String, size: int, col: Color) -> void:
	draw_string(_font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func _draw() -> void:
	var w := 320.0
	# level title strip
	draw_rect(Rect2(0, 0, w, 14), Color(0.03, 0.02, 0.07, 0.55))
	_label(Vector2(6, 10), level_title.to_upper(), 8, Color(0.85, 0.86, 1.0, 0.9))
	var time_int := int(elapsed)
	var time_str := "%d:%02d" % [time_int / 60, time_int % 60]
	draw_string(_font, Vector2(w - 56, 10), time_str, HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.75, 0.8, 1.0, 0.8))

	# coins
	var coin_col := Color("ffc93c")
	draw_rect(Rect2(w - 26, 3, 8, 8), coin_col)
	draw_rect(Rect2(w - 24, 5, 4, 4), Color("fff3b0"))
	draw_string(_font, Vector2(w - 16, 10), "%d/%d" % [coins_taken, coins_total], HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 0.95, 0.8, 0.95))

	# ability bar
	var slot := 22.0
	var gap := 3.0
	var slots := GameState.ABILITY_ORDER.size()
	var total_w := slot * float(slots) + gap * float(slots - 1)
	var bx := (w - total_w) * 0.5
	var by := 158.0
	draw_rect(Rect2(bx - 5, by - 5, total_w + 10, slot + 10), Color(0.03, 0.02, 0.08, 0.62))
	for i in slots:
		var ability: String = GameState.ABILITY_ORDER[i]
		var owned: bool = GameState.has(ability)
		var c: Color = GameState.color_of(ability)
		var x := bx + float(i) * (slot + gap)
		var r := Rect2(x, by, slot, slot)
		draw_rect(r, Color(0.07, 0.05, 0.14, 0.95))
		if owned:
			var pulse := 0.5 + 0.5 * sin(t * 3.0 + float(i))
			draw_rect(r.grow(1.0), Color(c.r, c.g, c.b, 0.35 + pulse * 0.25))
			draw_rect(r, Color(c.r * 0.25, c.g * 0.25, c.b * 0.35, 1.0))
			draw_rect(r, c, false, 1.0)
			Icons.draw_ability(self, ability, r.get_center() + Vector2(0, -2), 4.6, c)
			var key_hint: String = String(KEYS.get(ability, ""))
			if key_hint != "":
				draw_string(_font, Vector2(x + 1, by + slot - 1), key_hint, HORIZONTAL_ALIGNMENT_CENTER, slot - 2, 6, Color(c.r, c.g, c.b, 0.9))
		else:
			draw_rect(r, Color(0.08, 0.07, 0.12, 0.95))
			draw_rect(r, Color(0.25, 0.24, 0.34, 0.9), false, 1.0)
			Icons.draw_ability(self, ability, r.get_center(), 5.0, Color(0.28, 0.27, 0.37, 1.0))
			draw_line(r.position + Vector2(4, slot - 4), r.position + Vector2(slot - 4, 4), Color(0.35, 0.33, 0.45, 0.9), 1.0)

	# TIME STEAL meter: fills the bar while the world is slowed
	if GameState.is_slowed():
		var frac: float = GameState.slow_timer / GameState.SLOW_DURATION
		var meter := Rect2(bx - 5, by + slot + 7, total_w + 10, 2)
		draw_rect(meter, Color(0.08, 0.16, 0.18, 0.9))
		draw_rect(Rect2(meter.position, Vector2(meter.size.x * frac, meter.size.y)), GameState.color_of("time"))

	# controls reminder
	if elapsed < 9.0:
		draw_string(_font, Vector2(6, 176), "D MOVE   E STEAL   ESC PAUSE", HORIZONTAL_ALIGNMENT_LEFT, -1, 6, Color(0.7, 0.72, 0.95, 0.55))

	# steal prompt
	if prompt_ability != "":
		var c2: Color = GameState.color_of(prompt_ability)
		var label := "E  STEAL " + String(GameState.ability_name.get(prompt_ability, prompt_ability))
		var tw := 118.0
		var px := (w - tw) * 0.5
		var py := 92.0 + sin(t * 5.0) * 1.2
		draw_rect(Rect2(px, py, tw, 14), Color(0.02, 0.02, 0.06, 0.82))
		draw_rect(Rect2(px, py, tw, 14), c2, false, 1.0)
		Icons.draw_ability(self, prompt_ability, Vector2(px + 9, py + 7), 4.0, c2)
		_label(Vector2(px + 18, py + 10), label, 7, Color(1, 1, 1, 0.95))

	# hint
	if hint_timer > 0.0 and hint_text != "":
		var alpha := clampf(hint_timer, 0.0, 1.0)
		var tw2 := 268.0
		var px2 := (w - tw2) * 0.5
		draw_rect(Rect2(px2, 128, tw2, 22), Color(0.02, 0.02, 0.07, 0.72 * alpha))
		draw_rect(Rect2(px2, 128, tw2, 22), Color(0.5, 0.5, 0.85, 0.4 * alpha), false, 1.0)
		draw_multiline_string(_font, Vector2(px2 + 6, 137), hint_text, HORIZONTAL_ALIGNMENT_LEFT, tw2 - 12, 7, -1, Color(0.88, 0.9, 1.0, alpha))

	# toast
	if toast_timer > 0.0:
		var a := clampf(toast_timer * 1.6, 0.0, 1.0)
		var tw3 := 150.0
		var px3 := (w - tw3) * 0.5
		var py3 := 26.0 - (1.0 - a) * 3.0
		draw_rect(Rect2(px3, py3, tw3, 15), Color(0.02, 0.02, 0.06, 0.8 * a))
		draw_rect(Rect2(px3, py3, tw3, 15), Color(toast_color.r, toast_color.g, toast_color.b, a), false, 1.0)
		draw_string(_font, Vector2(px3 + 4, py3 + 11), toast_text, HORIZONTAL_ALIGNMENT_CENTER, tw3 - 8, 8, Color(1, 1, 1, a))

	# boss bar
	if boss_node != null and is_instance_valid(boss_node) and not boss_node.defeated_state:
		var bw := 180.0
		var bx2 := (w - bw) * 0.5
		var by2 := 18.0
		draw_rect(Rect2(bx2 - 2, by2 - 2, bw + 4, 12), Color(0.05, 0.02, 0.08, 0.9))
		draw_rect(Rect2(bx2, by2, bw, 8), Color(0.15, 0.05, 0.12, 1.0))
		var frac := clampf(float(boss_hp) / float(maxi(boss_max, 1)), 0.0, 1.0)
		var bcol := Color("ff4fa3") if boss_phase == 1 else (Color("ffd233") if boss_phase == 2 else Color("ff3b3b"))
		draw_rect(Rect2(bx2, by2, bw * frac, 8), bcol)
		draw_rect(Rect2(bx2, by2, bw * frac, 3), bcol.lightened(0.4))
		draw_rect(Rect2(bx2 - 2, by2 - 2, bw + 4, 12), Color(bcol.r, bcol.g, bcol.b, 0.7), false, 1.0)
		draw_string(_font, Vector2(bx2, by2 - 4), "THE CONTROL MASTER  -  PHASE %d" % boss_phase, HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(1, 0.85, 0.9, 0.95))
		var locked := ""
		if boss_node.locks.size() > 0:
			locked = String(boss_node.locks.keys()[0])
		if locked != "":
			draw_string(_font, Vector2(bx2 + bw * 0.5 - 30, by2 + 22), "LOCKED: " + String(GameState.ability_name.get(locked, locked)), HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(1, 0.5, 0.5, 0.9))

	# damage vignette
	if damage_flash > 0.0:
		var a2 := damage_flash * 0.8
		draw_rect(Rect2(0, 0, 320, 6), Color(1, 0.2, 0.3, a2))
		draw_rect(Rect2(0, 174, 320, 6), Color(1, 0.2, 0.3, a2))
		draw_rect(Rect2(0, 0, 6, 180), Color(1, 0.2, 0.3, a2 * 0.6))
		draw_rect(Rect2(314, 0, 6, 180), Color(1, 0.2, 0.3, a2 * 0.6))
