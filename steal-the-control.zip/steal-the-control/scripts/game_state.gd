extends Node
## Global run state + persistent save data. Autoloaded as "GameState".

signal abilities_changed
signal ability_gained(ability: String)
signal ability_lost(ability: String)

const SAVE_PATH := "user://save.json"
const ABILITY_ORDER := ["right", "jump", "left", "dash", "gravity", "time"]

var ability_name := {
	"right": "RIGHT",
	"jump": "JUMP",
	"left": "LEFT",
	"dash": "DASH",
	"gravity": "SPECIAL",
	"time": "TIME",
}

var ability_color := {
	"right": Color("ff4fa3"),
	"jump": Color("35c9ff"),
	"left": Color("4ade5e"),
	"dash": Color("ffd233"),
	"gravity": Color("a855f7"),
	"time": Color("58f0c8"),
}

var owned := {}
var current_level := 0
var unlocked_levels := 1
var completed := {}
var best_times := {}
const SETTING_DEFAULTS := {
	"fullscreen": true,
	"pixel_perfect": false,
	"screenshake": false,
}
const DEFAULTS_VERSION := 2

var settings := {}


func _ready() -> void:
	reset_abilities(["right"])
	load_game()
	ensure_settings()
	await get_tree().process_frame
	apply_display()


func reset_abilities(list: Array) -> void:
	owned.clear()
	for a in ABILITY_ORDER:
		owned[a] = list.has(a)
	owned["right"] = true
	abilities_changed.emit()


func has(ability: String) -> bool:
	return bool(owned.get(ability, false))


func grant(ability: String) -> bool:
	if not owned.has(ability) or owned[ability]:
		return false
	owned[ability] = true
	ability_gained.emit(ability)
	abilities_changed.emit()
	return true


func take(ability: String) -> bool:
	if ability == "right":
		return false
	if not has(ability):
		return false
	owned[ability] = false
	ability_lost.emit(ability)
	abilities_changed.emit()
	return true


func color_of(ability: String) -> Color:
	return ability_color.get(ability, Color.WHITE)


# --- TIME STEAL -------------------------------------------------------------
# Slows enemies and hazards only. The player keeps raw delta, so controls stay
# fully responsive while the world crawls - the whole point of the ability.

signal slow_changed(active: bool)

const SLOW_DURATION := 2.6
const SLOW_FACTOR := 0.30

var slow_timer := 0.0


func start_slow() -> bool:
	if slow_timer > 0.0:
		return false
	slow_timer = SLOW_DURATION
	slow_changed.emit(true)
	return true


## Multiplier for enemy/hazard delta. Never applied to the player.
func time_factor() -> float:
	return SLOW_FACTOR if slow_timer > 0.0 else 1.0


func is_slowed() -> bool:
	return slow_timer > 0.0


func _process(delta: float) -> void:
	if slow_timer <= 0.0:
		return
	slow_timer = maxf(slow_timer - delta, 0.0)
	if slow_timer <= 0.0:
		slow_changed.emit(false)


## Wipes campaign progress (levels, times, coins) but keeps settings and
## unlocks nothing beyond the first level. Used by "New Game".
func reset_progress() -> void:
	current_level = 0
	unlocked_levels = 1
	completed.clear()
	best_times.clear()
	save_game()
	abilities_changed.emit()


## True once the player has any progress worth continuing from.
func has_progress() -> bool:
	return unlocked_levels > 1 or not completed.is_empty()


func register_completion(index: int, time_seconds: float) -> void:
	var key := str(index)
	completed[key] = true
	var prev: float = float(best_times.get(key, 0.0))
	if prev <= 0.0 or time_seconds < prev:
		best_times[key] = time_seconds
	unlocked_levels = maxi(unlocked_levels, index + 2)
	save_game()


func ensure_settings() -> void:
	if typeof(settings) != TYPE_DICTIONARY:
		settings = {}
	for k in SETTING_DEFAULTS.keys():
		if not settings.has(k):
			settings[k] = SETTING_DEFAULTS[k]
	settings["defaults_version"] = DEFAULTS_VERSION


func setting(name: String) -> bool:
	ensure_settings()
	return bool(settings.get(name, SETTING_DEFAULTS.get(name, false)))


func set_setting(name: String, value: bool) -> void:
	ensure_settings()
	settings[name] = value


func save_game() -> void:
	ensure_settings()
	var data := {
		"unlocked_levels": unlocked_levels,
		"completed": completed,
		"best_times": best_times,
		"settings": settings,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data, "  "))
	f.close()


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var txt := f.get_as_text()
	f.close()
	if txt.strip_edges() == "":
		return
	var json := JSON.new()
	if json.parse(txt) != OK:
		# Corrupt save: ignore it rather than spraying engine errors.
		return
	var parsed: Variant = json.data
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed
	var u: Variant = d.get("unlocked_levels", 1)
	if typeof(u) == TYPE_FLOAT or typeof(u) == TYPE_INT:
		unlocked_levels = maxi(1, int(u))
	var c: Variant = d.get("completed", {})
	if typeof(c) == TYPE_DICTIONARY:
		completed = c
	var b: Variant = d.get("best_times", {})
	if typeof(b) == TYPE_DICTIONARY:
		best_times = b
	var s: Variant = d.get("settings", {})
	if typeof(s) == TYPE_DICTIONARY:
		settings = s
	ensure_settings()


## ---------------------------------------------------------------- display
## One place that owns window mode + viewport scaling so menus, HUD and
## gameplay all agree on how the 320x180 design space maps to the screen.

func apply_display() -> void:
	ensure_settings()
	if bool(settings.get("fullscreen", true)):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		_fit_windowed()
	apply_stretch(bool(settings.get("pixel_perfect", false)))


func toggle_fullscreen() -> void:
	set_setting("fullscreen", not setting("fullscreen"))
	apply_display()
	save_game()


func toggle_pixel_perfect() -> void:
	set_setting("pixel_perfect", not setting("pixel_perfect"))
	apply_display()
	save_game()


## Windowed mode: pick the largest 16:9 window that fits the monitor, so the
## game still looks intentional on 1366x768 laptops and 1920x1080 desktops.
func _fit_windowed() -> void:
	var screen := DisplayServer.window_get_current_screen()
	var usable := DisplayServer.screen_get_usable_rect(screen)
	var base := Vector2i(1280, 720)
	var scale := minf(float(usable.size.x - 96) / 1280.0, float(usable.size.y - 96) / 720.0)
	scale = clampf(scale, 0.4, 1.0)
	var target := Vector2i(int(1280.0 * scale), int(720.0 * scale))
	DisplayServer.window_set_size(target)
	var pos := usable.position + (usable.size - target) / 2
	DisplayServer.window_set_position(pos)


## canvas_items = the intended 16:9 area, letterboxed, never stretched.
## viewport = true integer scaling for purists (crisper, adds borders).
func apply_stretch(pixel_perfect: bool) -> void:
	var win := get_tree().root
	if win == null:
		return
	win.content_scale_factor = 1.0
	if pixel_perfect:
		var size := DisplayServer.window_get_size()
		var factor := maxi(1, mini(int(size.x) / 320, int(size.y) / 180))
		win.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT
		win.content_scale_size = Vector2i(320 * factor, 180 * factor)
		win.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP
	else:
		win.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
		win.content_scale_size = Vector2i(320, 180)
		win.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP
