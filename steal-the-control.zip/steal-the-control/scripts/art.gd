class_name Art
## Builds small pixel-art textures from ASCII maps at startup.
## No external image files, fully original art.

static func from_rows(rows: Array, palette: Dictionary) -> ImageTexture:
	var h := rows.size()
	var w := 0
	for r in rows:
		w = maxi(w, String(r).length())
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in h:
		var line: String = String(rows[y])
		for x in line.length():
			var ch := line[x]
			if palette.has(ch):
				img.set_pixel(x, y, palette[ch])
	return ImageTexture.create_from_image(img)


static func coin() -> ImageTexture:
	var p := {
		"Y": Color("ffc93c"),
		"W": Color("ffe27a"),
		"w": Color("fff8d6"),
	}
	return from_rows([
		"..Y..",
		".YWY.",
		"YWwWY",
		".YWY.",
		"..Y..",
	], p)


static func door() -> ImageTexture:
	var p := {
		"K": Color("ff4fa3"),
		"D": Color("1d1338"),
		"L": Color("4a356f"),
		"G": Color("c39bff"),
	}
	return from_rows([
		"...KKKKKK...",
		"..KDDDDDDK..",
		".KDLLLLLLDK.",
		".KDLLLLLLDK.",
		".KDLLGLLLDK.",
		".KDLLGLLLDK.",
		".KDLLLLLLDK.",
		".KDLLLLLLDK.",
		".KDLGLLLLDK.",
		".KDLGLLLLDK.",
		".KDLLLLLLDK.",
		".KDLLLLLLDK.",
		".KDDDDDDDDK.",
		"..KDDDDDDK..",
		"...KKKKKK...",
	], p)


static func flag() -> ImageTexture:
	var p := {
		"P": Color("cfd3ff"),
		"F": Color("4ade5e"),
		"B": Color("1b1436"),
	}
	return from_rows([
		"B.......",
		"BFFFFFF.",
		"BFFFFF..",
		"BFFFF...",
		"BFFF....",
		"BF......",
		"B.......",
		"B.......",
		"B.......",
		"B.......",
		"B.......",
	], p)
