extends Node
## Phase 1 core regression suite.
##
## Run:
##   Summer.exe --headless --path <project> res://tests/test_core.tscn
##
## Exit code 0 = all checks passed, 1 = at least one failed.
##
## It uses the real InputMap, the real GameState autoload, the real player
## scene and the real Enemy class. The user's save file is backed up before the
## save/load checks and restored byte-for-byte afterwards.

const FLOOR_TOP := 84.0
const CEIL_BOTTOM := -84.0
const WATCHDOG_SECONDS := 70.0
const ACTIONS := ["move_left", "move_right", "jump", "dash", "special", "steal"]

var player: Player = null
var world: Node2D = null
var gs: Node = null
var checks := 0
var failures := 0
var finished := false
var elapsed := 0.0
var _save_backup: PackedByteArray = PackedByteArray()
var _save_existed := false


func _ready() -> void:
	print("[test] Phase 1 core regression suite")
	_run()


func _process(delta: float) -> void:
	if finished:
		return
	elapsed += delta
	if elapsed > WATCHDOG_SECONDS:
		finished = true
		_restore_save()
		print("[FAIL] watchdog - test did not finish within %.0f s" % WATCHDOG_SECONDS)
		get_tree().quit(1)


func _run() -> void:
	gs = get_node_or_null("/root/GameState")
	check("autoload_gamestate", gs != null, "GameState autoload is available")
	if gs == null:
		finished = true
		get_tree().quit(1)
		return

	_backup_save()
	_build_world()
	await _wait(40)

	await _test_input_map()
	await _test_movement_gating()
	await _test_dash()
	await _test_gravity()
	await _test_stealing()
	await _test_respawn()
	_test_save_load()
	_test_level_progression()
	await _test_enemy_activity()
	await _test_time_steal()
	await _test_checkpoint_safety()

	_restore_save()
	finished = true
	print("[test] %d/%d checks passed" % [checks - failures, checks])
	get_tree().quit(0 if failures == 0 else 1)


## ---------------------------------------------------------------- input map
func _test_input_map() -> void:
	for a in ACTIONS:
		var has_action: bool = InputMap.has_action(a)
		check("input_has_%s" % a, has_action, "action '%s' exists in the InputMap" % a)
		if has_action:
			check("input_bound_%s" % a, InputMap.action_get_events(a).size() > 0, "action '%s' has at least one event" % a)

	# The reported bug was Space doing nothing: prove Space is really JUMP.
	var space_found := false
	if InputMap.has_action("jump"):
		for ev in InputMap.action_get_events("jump"):
			var ke := ev as InputEventKey
			if ke != null and (ke.keycode == KEY_SPACE or ke.physical_keycode == KEY_SPACE):
				space_found = true
	check("space_bound_to_jump", space_found, "SPACE is bound to the 'jump' action")
	await _wait(2)


## ------------------------------------------------------- movement gating
func _test_movement_gating() -> void:
	gs.reset_abilities(["right"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))

	# RIGHT is free from the start.
	var x0: float = player.global_position.x
	Input.action_press("move_right")
	await _wait(30)
	Input.action_release("move_right")
	var dx_right: float = player.global_position.x - x0
	check("moves_right_at_start", dx_right > 20.0, "player moved right %.1f px with only RIGHT owned (need > 20)" % dx_right)

	# LEFT must stay locked until stolen.
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	x0 = player.global_position.x
	Input.action_press("move_left")
	await _wait(30)
	Input.action_release("move_left")
	var dx_locked: float = player.global_position.x - x0
	check("left_locked_before_steal", dx_locked > -3.0, "left is refused while LEFT is not owned (moved %.1f px)" % dx_locked)

	# After stealing LEFT it must work.
	gs.grant("left")
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	x0 = player.global_position.x
	Input.action_press("move_left")
	await _wait(30)
	Input.action_release("move_left")
	var dx_left: float = player.global_position.x - x0
	check("moves_left_after_steal", dx_left < -20.0, "player moved left %.1f px once LEFT is owned (need < -20)" % dx_left)

	# DASH input must be inert without the ability.
	gs.reset_abilities(["right", "left"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	Input.action_press("dash")
	await _wait(3)
	Input.action_release("dash")
	check("dash_locked_without_ability", player.dash_timer <= 0.0, "dash does not start while DASH is not owned")


## ------------------------------------------------------------------- dash
func _test_dash() -> void:
	gs.reset_abilities(["right", "left", "dash"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	player.facing = 1.0
	player._start_dash()
	check("dash_starts", player.dash_timer > 0.0, "dash timer armed after a dash request")
	var x0: float = player.global_position.x
	await _wait(12)
	var dist: float = player.global_position.x - x0
	check("dash_moves_horizontally", dist > 25.0, "dash covered %.1f px (need > 25)" % dist)
	await _wait(40)
	var grounded: bool = player.is_on_floor()
	check("dash_ends_grounded", grounded, "player is still on the floor after dashing")


## ----------------------------------------------------------------- gravity
func _test_gravity() -> void:
	gs.reset_abilities(["right", "jump", "left", "dash", "gravity"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	check("special_locked_off_cooldown", player.special_cd <= 0.0, "SPECIAL is ready before use")

	player._flip_gravity()
	check("gravity_flips", player.gravity_sign < 0.0, "gravity_sign is -1 after SPECIAL")
	check("up_direction_inverts", player.up_direction.y > 0.0, "up_direction points down when gravity is reversed")

	player.gravity_timer = 9999.0
	await _wait(140)
	check("stands_on_ceiling", player.is_on_floor(), "is_on_floor() is true while resting on the ceiling")
	check("stays_high_while_inverted", player.global_position.y < 0.0, "player is up near the ceiling while inverted")

	# Expiry must restore normal gravity and normal floor detection.
	player.gravity_timer = 0.02
	await _wait(6)
	check("gravity_restores", player.gravity_sign > 0.0, "gravity returns to normal when SPECIAL expires")
	check("up_direction_restores", player.up_direction.y < 0.0, "up_direction is (0,-1) again after SPECIAL expires")
	await _wait(160)
	check("falls_back_to_floor", player.is_on_floor() and player.global_position.y > 40.0, "player falls back down and lands on the floor")


## ---------------------------------------------------------------- stealing
func _test_stealing() -> void:
	gs.reset_abilities(["right"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))

	var e := Enemy.new()
	e.kind = "blue"
	e.position = Vector2(12, FLOOR_TOP - 8.0)
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	cs.position = Vector2(0, -6)
	e.add_child(cs)
	world.add_child(e)
	e.set_physics_process(false)  # freeze so the range check is deterministic
	await _wait(2)

	check("enemy_carries_jump", e.has_ability_available() and e.target_ability() == "jump", "blue enemy carries JUMP")
	check("jump_not_owned_yet", not gs.has("jump"), "JUMP is not owned before stealing")
	check("prompt_targets_enemy", player.nearest_stealable() == e, "nearest_stealable() finds the blue enemy in range")

	player._try_steal()
	await _wait(2)
	check("steal_grants_jump", gs.has("jump"), "pressing steal grants JUMP through GameState")
	check("enemy_loses_ability", not e.has_ability_available(), "enemy no longer carries JUMP after the steal")
	check("enemy_stunned", e.stun_time > 0.0, "stolen enemy is stunned briefly (no instant re-steal)")

	# Stealing twice must not duplicate or crash, and must not regrant.
	gs.take("jump")
	player._try_steal()
	await _wait(2)
	check("no_repeat_steal_exploit", not gs.has("jump"), "a spent enemy cannot be stolen from again")

	# Out of range: nothing happens.
	var e2 := Enemy.new()
	e2.kind = "green"
	e2.position = Vector2(400, FLOOR_TOP - 8.0)
	world.add_child(e2)
	e2.set_physics_process(false)
	await _wait(2)
	check("steal_needs_range", player.nearest_stealable() == null, "enemies outside STEAL_RANGE are not targetable")
	e2.queue_free()
	e.queue_free()
	await _wait(2)


## ---------------------------------------------------------------- respawn
func _test_respawn() -> void:
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	player.kill()
	check("kill_disables_control", not player.alive and not player.control_enabled, "killing the player disables input")
	await _wait(10)

	player.respawn(Vector2(0, FLOOR_TOP - 2.0))
	check("respawn_revives", player.alive and player.control_enabled, "respawn restores life and control")
	check("respawn_resets_velocity", player.velocity.length() < 1.0, "respawn clears velocity")
	check("respawn_resets_gravity", player.gravity_sign > 0.0 and player.up_direction.y < 0.0, "respawn restores normal gravity and up_direction")
	await _wait(40)
	check("respawn_lands", player.is_on_floor(), "respawned player settles on the floor")


## -------------------------------------------------------------- save/load
func _test_save_load() -> void:
	var path := "user://save.json"
	gs.unlocked_levels = 7
	gs.completed = {"0": true, "3": true}
	gs.best_times = {"0": 21.5}
	gs.set_setting("screenshake", true)
	gs.save_game()

	# Wipe in memory, then reload from disk.
	gs.unlocked_levels = 1
	gs.completed = {}
	gs.best_times = {}
	gs.set_setting("screenshake", false)
	gs.load_game()

	check("save_unlocked_levels", int(gs.unlocked_levels) == 7, "unlocked_levels round-trips (got %d)" % int(gs.unlocked_levels))
	check("save_completed", bool(gs.completed.get("3", false)), "completed levels round-trip")
	check("save_best_times", is_equal_approx(float(gs.best_times.get("0", 0.0)), 21.5), "best times round-trip")
	check("save_settings", bool(gs.setting("screenshake")), "settings round-trip")

	# A corrupted save must never crash and must keep sane defaults.
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f != null:
		f.store_string("{ this is not json ][")
		f.close()
	gs.load_game()
	check("corrupt_save_survives", int(gs.unlocked_levels) >= 1, "a corrupted save file does not crash loading")
	check("corrupt_save_has_settings", gs.settings.size() > 0, "settings are repaired after a corrupted save")
	gs.unlocked_levels = 1
	gs.completed = {}
	gs.best_times = {}


## --------------------------------------------- all 15 levels progression
func _test_level_progression() -> void:
	var all: Array = Levels.all()
	check("level_count", all.size() == Levels.COUNT, "all %d levels are defined (got %d)" % [Levels.COUNT, all.size()])

	var bad_exit := 0
	var bad_spawn := 0
	var impossible := 0
	for i in all.size():
		var d: Dictionary = all[i]
		var solids: Array = d.get("solids", [])
		if solids.is_empty():
			bad_spawn += 1
			continue
		var sp: Array = d.get("spawn", [0, 0])
		if not _surface_below(solids, float(sp[0]) * 16.0 + 8.0):
			bad_spawn += 1
		var ex: Array = d.get("exit", [0, 0])
		if not _surface_below(solids, float(ex[0]) * 16.0 + 8.0):
			bad_exit += 1

		# Every ability a door demands must be owned at start or carried by an
		# enemy on the same level: that is the no-softlock rule.
		var start: Array = d.get("start", [])
		var carried := {}
		for e in d.get("enemies", []):
			var kind := String(e[0])
			var ab := _ability_of(kind)
			if ab != "":
				carried[ab] = true
		for door in d.get("doors", []):
			for req in door.get("requires", []):
				var r := String(req)
				if not start.has(r) and not carried.has(r):
					impossible += 1
					print("[diag] level %d door needs '%s' but nothing on the level grants it" % [i + 1, r])

	check("all_exits_on_ground", bad_exit == 0, "every exit sits above a solid surface (%d bad)" % bad_exit)
	check("all_spawns_on_ground", bad_spawn == 0, "every spawn sits above a solid surface (%d bad)" % bad_spawn)
	check("no_impossible_doors", impossible == 0, "every ability-gated door is satisfiable on its level (%d impossible)" % impossible)


func _ability_of(kind: String) -> String:
	match kind:
		"blue":
			return "jump"
		"green":
			return "left"
		"yellow":
			return "dash"
		"purple":
			return "gravity"
	return ""


func _surface_below(solids: Array, x: float) -> bool:
	for s in solids:
		var left := float(s[0]) * 16.0
		var right := left + float(s[2]) * 16.0
		if x >= left - 1.0 and x <= right + 1.0:
			return true
	return false


## --------------------------------------------------------- enemy activity
func _test_time_steal() -> void:
	gs.slow_timer = 0.0
	gs.reset_abilities(["right"])
	for n in get_tree().get_nodes_in_group("enemies"):
		n.queue_free()
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))

	check("time_locked_at_start", not gs.has("time"), "TIME is not owned at level start")
	player.request_time_steal()
	await _wait(2)
	check("time_requires_ability", not gs.is_slowed(), "TIME STEAL is refused without the ability")

	# a teal chrono wisp is the carrier
	var w := Enemy.new()
	w.kind = "teal"
	w.position = Vector2(14, FLOOR_TOP - 8.0)
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	cs.position = Vector2(0, -6)
	w.add_child(cs)
	world.add_child(w)
	w.set_physics_process(false)
	await _wait(2)
	check("teal_carries_time", w.has_ability_available() and w.target_ability() == "time", "teal wisp carries TIME")
	check("teal_targeted", player.nearest_stealable() == w, "nearest_stealable() finds the teal wisp")
	player._try_steal()
	await _wait(2)
	check("steal_grants_time", gs.has("time"), "stealing grants TIME through GameState")

	# Baseline: how far a green walker travels at normal speed. The player is
	# parked far away so the walker stays in plain patrol instead of switching
	# into its 1.9x chase speed and masking the comparison.
	player.global_position = Vector2(-400, FLOOR_TOP - 2.0)
	player.velocity = Vector2.ZERO
	await _wait(4)
	var walker := Enemy.new()
	walker.kind = "green"
	walker.position = Vector2(120, FLOOR_TOP)
	var cs2 := CollisionShape2D.new()
	var sh2 := RectangleShape2D.new()
	sh2.size = Vector2(12, 12)
	cs2.shape = sh2
	cs2.position = Vector2(0, -6)
	walker.add_child(cs2)
	world.add_child(walker)
	await _wait(30)
	var x0: float = walker.global_position.x
	await _wait(30)
	var fast: float = absf(walker.global_position.x - x0)

	player.request_time_steal()
	await _wait(2)
	check("time_slows_world", gs.is_slowed() and gs.time_factor() < 1.0, "TIME STEAL engages a slow factor")

	var x1: float = walker.global_position.x
	await _wait(30)
	var slow_d: float = absf(walker.global_position.x - x1)
	check("enemy_moves_slower", slow_d < fast * 0.72, "enemy covers %.1f px slowed vs %.1f px normal" % [slow_d, fast])

	# the player must stay at full speed while the world crawls
	player.global_position = Vector2(-40, FLOOR_TOP - 2.0)
	player.velocity = Vector2.ZERO
	await _wait(4)
	var px0: float = player.global_position.x
	Input.action_press("move_right")
	await _wait(30)
	Input.action_release("move_right")
	var player_d: float = player.global_position.x - px0
	check("player_keeps_full_speed", player_d > 40.0, "player still covers %.1f px while slowed (need > 40)" % player_d)

	# expiry + cooldown
	check("time_on_cooldown", player.time_cd > 0.0, "TIME STEAL goes on cooldown after use")
	gs.slow_timer = 0.02
	await _wait(4)
	check("time_expires", not gs.is_slowed() and gs.time_factor() == 1.0, "the slow wears off on its own")
	player.request_time_steal()
	await _wait(2)
	check("time_respects_cooldown", not gs.is_slowed(), "TIME STEAL is refused while cooling down")

	w.queue_free()
	walker.queue_free()
	await _wait(2)


func _test_enemy_activity() -> void:
	var e := Enemy.new()
	e.kind = "green"
	# The enemy shape spans -12..0 around its origin, so position.y is the
	# exact floor contact point. Off the player's x so it patrols freely.
	e.position = Vector2(120, FLOOR_TOP)
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	cs.position = Vector2(0, -6)
	e.add_child(cs)
	world.add_child(e)
	var start_x: float = e.global_position.x
	var start_y: float = e.global_position.y
	await _wait(60)
	var moved: float = absf(e.global_position.x - start_x)
	var drift: float = absf(e.global_position.y - start_y)
	check("enemy_moves", moved > 3.0, "green walker patrols (moved %.1f px)" % moved)
	check("enemy_on_floor", drift < 6.0, "enemy rests on the floor instead of falling (drift %.1f px)" % drift)
	e.queue_free()
	await _wait(2)


## ------------------------------------------------------------------ utils
func _build_world() -> void:
	world = Node2D.new()
	world.name = "TestWorld"
	add_child(world)

	_add_body(Vector2(0, FLOOR_TOP + 16.0), Vector2(2400, 32))
	_add_body(Vector2(0, CEIL_BOTTOM - 16.0), Vector2(2400, 32))
	_add_body(Vector2(-600, 0), Vector2(32, 400))
	_add_body(Vector2(600, 0), Vector2(32, 400))

	player = load("res://scenes/player.tscn").instantiate()
	player.position = Vector2(0, FLOOR_TOP - 2.0)
	world.add_child(player)


func _add_body(pos: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	body.position = pos
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	world.add_child(body)


func _reset_player(pos: Vector2) -> void:
	Input.action_release("move_left")
	Input.action_release("move_right")
	Input.action_release("dash")
	Input.action_release("jump")
	player.respawn(pos)
	player.dash_timer = 0.0
	player.dash_cd = 0.0
	player.special_cd = 0.0
	await _wait(20)


func _wait(frames: int) -> void:
	for i in frames:
		await get_tree().physics_frame


func _backup_save() -> void:
	var path := "user://save.json"
	_save_existed = FileAccess.file_exists(path)
	if _save_existed:
		var f := FileAccess.open(path, FileAccess.READ)
		if f != null:
			_save_backup = f.get_buffer(f.get_length())
			f.close()


func _restore_save() -> void:
	var path := "user://save.json"
	if _save_existed and _save_backup.size() > 0:
		var f := FileAccess.open(path, FileAccess.WRITE)
		if f != null:
			f.store_buffer(_save_backup)
			f.close()
	elif not _save_existed:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))


## Every checkpoint in all 15 levels must be standable, clear of spikes,
## outside enemy patrol sweeps, and away from moving-platform paths.
func _test_checkpoint_safety() -> void:
	var all_levels: Array = Levels.all()
	var total := 0
	var bad := 0
	var report: Array = []
	for idx in all_levels.size():
		var d: Dictionary = all_levels[idx]
		var results: Array = LevelBuilder.checkpoint_safety(d)
		for r in results:
			total += 1
			var issues: Array = r["issues"]
			if not issues.is_empty():
				bad += 1
				report.append("L%d %s -> %s at %s" % [idx + 1, String(d.get("name", "")), str(issues), str(r["pos"])])
	check("checkpoint_count", total >= 14, "levels define %d checkpoints in total" % total)
	check("all_checkpoints_safe", bad == 0, "unsafe checkpoints: %d%s" % [bad, "" if report.is_empty() else " | " + "; ".join(report)])

	# ---- respawn protection
	gs.reset_abilities(["right"])
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	player.kill()
	await _wait(2)
	player.respawn(Vector2(0, FLOOR_TOP - 2.0))
	check("respawn_grants_invuln", player.invuln > 1.0, "respawn arms %.2fs of grace" % player.invuln)
	await _wait(100)
	check("invuln_expires", player.invuln <= 0.0, "grace expires on its own (%.2f)" % player.invuln)

	# ---- an enemy standing on the respawn point must not kill instantly
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	var e := Enemy.new()
	e.kind = "green"
	e.position = Vector2(0, FLOOR_TOP)
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	cs.position = Vector2(0, -6)
	e.add_child(cs)
	world.add_child(e)
	e.set_physics_process(false)
	await _wait(2)
	player.kill()
	await _wait(2)
	player.respawn(Vector2(0, FLOOR_TOP - 2.0))
	await _wait(20)
	check("enemy_cannot_kill_during_grace", player.alive, "player survives an enemy overlapping the respawn point")
	e.queue_free()
	await _wait(2)

	# ---- guard_spawn shoves and stuns enemies near the respawn point
	await _reset_player(Vector2(0, FLOOR_TOP - 2.0))
	var e2 := Enemy.new()
	e2.kind = "green"
	e2.position = Vector2(10, FLOOR_TOP)
	var cs2 := CollisionShape2D.new()
	var sh2 := RectangleShape2D.new()
	sh2.size = Vector2(12, 12)
	cs2.shape = sh2
	cs2.position = Vector2(0, -6)
	e2.add_child(cs2)
	world.add_child(e2)
	await _wait(2)
	var lb := LevelBuilder.new()
	world.add_child(lb)
	lb.enemies.append(e2)
	lb.guard_spawn(Vector2(0, FLOOR_TOP - 2.0))
	lb.queue_free()
	check("guard_spawn_stuns", e2.stun_time > 0.5, "enemy near the respawn point is stunned (%.2f)" % e2.stun_time)
	check("guard_spawn_pushes", absf(e2.velocity.x) > 40.0, "and shoved away (vx %.1f)" % e2.velocity.x)
	e2.queue_free()
	await _wait(2)


func check(id: String, ok: bool, detail: String) -> void:
	checks += 1
	if not ok:
		failures += 1
	print("[%s] %s - %s" % ["PASS" if ok else "FAIL", id, detail])
