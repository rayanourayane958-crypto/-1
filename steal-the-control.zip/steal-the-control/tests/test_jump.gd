extends Node
## Headless regression test for the JUMP ability.
##
## Run:
##   Summer.exe --headless --path <project> res://tests/test_jump.tscn
##
## Exit code 0 = all checks passed, 1 = at least one failed.
## It builds a real floor and ceiling, spawns the real player scene, grants
## JUMP through the real GameState ability system, and drives the exact same
## request_jump() path the Space key uses.

const FLOOR_TOP := 84.0
const CEIL_BOTTOM := -84.0
const WATCHDOG_SECONDS := 40.0

var player: Player = null
var checks := 0
var failures := 0
var finished := false
var elapsed := 0.0


func _ready() -> void:
	print("[test] JUMP ability regression test")
	_run()


func _process(delta: float) -> void:
	if finished:
		return
	elapsed += delta
	if elapsed > WATCHDOG_SECONDS:
		finished = true
		print("[FAIL] watchdog - test did not finish within %.0f s" % WATCHDOG_SECONDS)
		get_tree().quit(1)


func _run() -> void:
	var gs: Node = get_node_or_null("/root/GameState")
	check("autoload_gamestate", gs != null, "GameState autoload is available")
	_build_world()
	await _wait(40)

	print("[diag] on_floor=%s up=%s pos=%s vel=%s sign=%.1f" % [
		player.is_on_floor(), player.up_direction, player.global_position,
		player.velocity, player.gravity_sign])
	check("stands_on_floor", player.is_on_floor(), "is_on_floor() is true while resting on solid ground")

	player.debug_jump = true

	# ---- 1. locked before stealing
	check("jump_locked_before_steal", not gs.has("jump"), "JUMP is not owned at level start")
	var y0: float = player.global_position.y
	player.request_jump()
	await _wait(10)
	var drift: float = y0 - player.global_position.y
	check("no_jump_without_ability", drift < 3.0, "no jump without the ability (rose %.1f px)" % drift)

	# ---- 2. grant through the real ability system
	gs.grant("jump")
	await _wait(20)
	check("jump_owned_after_grant", gs.has("jump"), "GameState reports JUMP as owned")

	# ---- 3. first jump rises
	y0 = player.global_position.y
	var peak := y0
	player.request_jump()
	await _wait(2)
	print("[diag] post-request: buffer=%.3f coyote=%.3f vel=%s" % [
		player.jump_buffer, player.coyote, player.velocity])
	for i in 34:
		await _wait(1)
		peak = minf(peak, player.global_position.y)
	var rise: float = y0 - peak
	check("jump_rises", rise >= 8.0, "player rises %.1f px (need >= 8)" % rise)

	# ---- 4. lands normally
	await _wait(90)
	check("jump_lands", player.is_on_floor(), "player is on the floor again")
	var back: float = absf(player.global_position.y - y0)
	check("jump_returns_to_ground", back < 4.0, "landed %.1f px from start (need < 4)" % back)

	# ---- 5. jumping repeats
	var y1: float = player.global_position.y
	var peak2 := y1
	player.request_jump()
	for i in 34:
		await _wait(1)
		peak2 = minf(peak2, player.global_position.y)
	var rise2: float = y1 - peak2
	check("jump_repeats", rise2 >= 8.0, "second jump rises %.1f px (need >= 8)" % rise2)
	await _wait(90)

	# ---- 6. reversed gravity: stand on the ceiling and jump off it
	player._flip_gravity()
	player.gravity_timer = 9999.0
	await _wait(90)
	print("[diag] reversed: on_floor=%s up=%s pos=%s" % [
		player.is_on_floor(), player.up_direction, player.global_position])
	check("reversed_gravity_on_ceiling", player.is_on_floor(), "is_on_floor() is true while resting on the ceiling")
	var y2: float = player.global_position.y
	var peak3 := y2
	player.request_jump()
	for i in 34:
		await _wait(1)
		peak3 = maxf(peak3, player.global_position.y)
	var rise3: float = peak3 - y2
	check("jump_under_reversed_gravity", rise3 >= 8.0, "jump launches %.1f px off the ceiling (need >= 8)" % rise3)

	finished = true
	print("[test] %d/%d checks passed" % [checks - failures, checks])
	get_tree().quit(0 if failures == 0 else 1)


func _build_world() -> void:
	var world := Node2D.new()
	world.name = "TestWorld"
	add_child(world)

	_add_body(world, Vector2(0, FLOOR_TOP + 16.0), Vector2(1400, 32))
	_add_body(world, Vector2(0, CEIL_BOTTOM - 16.0), Vector2(1400, 32))
	_add_body(world, Vector2(-180, 0), Vector2(32, 400))
	_add_body(world, Vector2(180, 0), Vector2(32, 400))

	player = load("res://scenes/player.tscn").instantiate()
	player.position = Vector2(0, FLOOR_TOP - 2.0)
	world.add_child(player)


func _add_body(parent: Node, pos: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	body.position = pos
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	parent.add_child(body)


func _wait(frames: int) -> void:
	for i in frames:
		await get_tree().physics_frame


func check(id: String, ok: bool, detail: String) -> void:
	checks += 1
	if not ok:
		failures += 1
	print("[%s] %s - %s" % ["PASS" if ok else "FAIL", id, detail])
